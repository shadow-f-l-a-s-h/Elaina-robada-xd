import fetch from 'node-fetch';

// CONFIGURACIÓN DE TU REPOSITORIO DE GITHUB
const GITHUB_TOKEN = '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'; // Personal Access Token
const REPO_OWNER = 'mai1206-art';                             // Usuario de GitHub
const REPO_NAME = 'elaina';                                   // Nombre del repositorio
const BRANCH = 'main';                                        // Rama principal

export default {
  command: ['mkdir', 'crearcarpeta', 'newfolder'],
  category: 'owner',
  description: 'Gestor avanzado de carpetas y subcarpetas con o sin código inicial para GitHub.',
  isOwner: true, // Manejo nativo de permisos del bot
  run: async ({ sock, msg, usedPrefix, command, text }) => {

    // Menú interactivo de ayuda si el usuario manda el comando vacío
    if (!text || !text.trim()) {
      const menuHelp = `📁 *MENÚ Y GUÍA DE USO DE CREACIÓN DE CARPETAS* 📁

Usa este comando para estructurar tu repositorio en GitHub desde WhatsApp.

━━━━━━━━━━━━━━━━━━━━━━
📌 *1. Crear Carpeta Principal*
> Sintaxis: \`${usedPrefix + command} <nombre_carpeta>\`
> Ejemplo: \`${usedPrefix + command} utils\`

📌 *2. Crear Subcarpeta*
> Sintaxis: \`${usedPrefix + command} <carpeta_padre>/<subcarpeta>\`
> Ejemplo: \`${usedPrefix + command} cmds/admin\`

📌 *3. Crear Carpeta + Archivo con Código directo*
> Sintaxis: \`${usedPrefix + command} <ruta/archivo.js> | <código>\`
> Ejemplo:
\`${usedPrefix + command} plugins/games/ruleta.js | export default { command: ['ruleta'] }\`
━━━━━━━━━━━━━━━━━━━━━━
💡 *Nota:* Si solo indicas la carpeta, se añadirá automáticamente un archivo \`.gitkeep\` para fijarla en GitHub.`;

      return msg.reply(menuHelp);
    }

    await msg.react('⏳');

    try {
      // Separar la ruta del código (si se incluyó con '|')
      const [rawPath, ...codeParts] = text.split('|');
      const targetPath = rawPath.trim().replace(/^\/+|\/+$/g, '');
      const rawCode = codeParts.join('|').trim();

      // Analizar si es una carpeta principal o una subcarpeta
      const pathSegments = targetPath.split('/');
      const isSubfolder = pathSegments.length > 1;
      const folderType = isSubfolder ? 'Subcarpeta' : 'Carpeta Principal';

      let finalFilePath = '';
      let fileContent = '';
      let commitMessage = '';

      // Determinar si se enviará con archivo de código o con .gitkeep
      if (rawCode) {
        finalFilePath = targetPath.includes('.') ? targetPath : `${targetPath}/index.js`;
        fileContent = rawCode;
        commitMessage = `build: crear ${folderType.toLowerCase()} ${targetPath} con código vía WhatsApp`;
      } else {
        finalFilePath = targetPath.includes('.') ? targetPath : `${targetPath}/.gitkeep`;
        fileContent = `# ${folderType} [${targetPath}] generada mediante bot de WhatsApp\n`;
        commitMessage = `build: crear ${folderType.toLowerCase()} ${targetPath} vía WhatsApp`;
      }

      const url = `https://api.github.com/repos/${REPO_OWNER}/${REPO_NAME}/contents/${finalFilePath}`;
      const contentBase64 = Buffer.from(fileContent).toString('base64');

      const response = await fetch(url, {
        method: 'PUT',
        headers: {
          'Authorization': `token ${GITHUB_TOKEN}`,
          'Accept': 'application/vnd.github.v3+json',
          'Content-Type': 'application/json',
          'User-Agent': 'WhatsApp-Bot-Script'
        },
        body: JSON.stringify({
          message: commitMessage,
          content: contentBase64,
          branch: BRANCH
        })
      });

      const data = await response.json();

      if (response.status === 201 || response.status === 200) {
        await msg.react('✅');
        let responseMsg = `✅ *${folderType.toUpperCase()} CREADA EN GITHUB*\n\n`;
        responseMsg += `📂 *Tipo:* ${folderType}\n`;
        responseMsg += `📁 *Ruta asignada:* \`${finalFilePath}\`\n`;
        responseMsg += `🔗 *Commit SHA:* \`${data.commit.sha.substring(0, 7)}\`\n`;
        responseMsg += `📝 *Incluye Código:* ${rawCode ? 'Sí' : 'No (.gitkeep)'}\n\n`;
        responseMsg += `📌 *Paso final:* Ejecuta tu comando \`.fix\` para actualizar el bot localmente.`;

        await msg.reply(responseMsg);
      } else {
        await msg.react('❌');
        await msg.reply(`❌ *Error de respuesta desde GitHub API:*\n> ${data.message || 'Error desconocido al subir la estructura.'}`);
      }

    } catch (error) {
      await msg.react('❌');
      await msg.reply(`⚠️ *Excepción durante la ejecución:*\n> ${error.message}`);
    }
  }
};
