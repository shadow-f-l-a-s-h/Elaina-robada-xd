export default {
  command: ['aviso'],
  isOwner: true,
  category: 'owner',

  run: async ({ sock, msg, args }) => {
    const destinos = [
      //'120363429827635405@g.us', 
      //grupo avisos 
      '120363426046552630@newsletter'
      //canal
    ]

    try {
      const textoArgs = args.join(' ').trim()
      const hasQuoted =!!msg.quoted
      const hasOwnMedia =!!msg.message?.imageMessage ||!!msg.message?.videoMessage ||!!msg.message?.stickerMessage ||!!msg.message?.documentMessage ||!!msg.message?.audioMessage

      if (!textoArgs &&!hasQuoted &&!hasOwnMedia) {
        return sock.sendMessage(msg.chat, { text: `《✧》 *Comando Aviso*\n\n*Uso:*\n-.aviso <texto>\n-.aviso + imagen/video/gif/sticker\n- Responde a un mensaje con.aviso\n\nEnvía el aviso a los grupos y canales configurados.` }, { quoted: msg })
      }

      const broadcast = async (payload) => {
        for (const target of destinos) {
          try {
            await sock.sendMessage(target, payload)
          } catch (err) {
            console.error(`[Aviso] Error enviando a ${target}:`, err)
          }
        }
      }

      await sock.sendMessage(msg.chat, { react: { text: '📢', key: msg.key } })

      let source = null
      if (hasQuoted) source = msg.quoted
      else if (hasOwnMedia) source = msg

      let buffer = null
      let mime = ''
      let isGif = false

      if (source) {
        mime = source.mime || source.mimetype || source.mediaType || msg.mimetype || ''
        isGif = source.message?.videoMessage?.gifPlayback || msg.message?.videoMessage?.gifPlayback || false
        try {
          buffer = await source.download()
        } catch {}
      }

      const text = textoArgs || source?.text || source?.caption || ''

      if (buffer) {
        if (/webp/.test(mime) || mime.includes('sticker')) {
          await broadcast({ sticker: buffer })
          return sock.sendMessage(msg.chat, { text: '《✧》 *Aviso sticker enviado.*' }, { quoted: msg })
        }
        if (/image/.test(mime)) {
          await broadcast({ image: buffer, caption: text })
          return sock.sendMessage(msg.chat, { text: '《✧》 *Aviso imagen enviado.*' }, { quoted: msg })
        }
        if (/video/.test(mime)) {
          await broadcast({ video: buffer, caption: text, gifPlayback: isGif, mimetype: 'video/mp4' })
          return sock.sendMessage(msg.chat, { text: `《✧》 *Aviso ${isGif? 'gif' : 'video'} enviado.*` }, { quoted: msg })
        }
        if (/audio/.test(mime)) {
          await broadcast({ audio: buffer, mimetype: 'audio/mp4', ptt: true })
          return sock.sendMessage(msg.chat, { text: '《✧》 *Aviso audio enviado.*' }, { quoted: msg })
        }
        await broadcast({ document: buffer, mimetype: mime || 'application/octet-stream', fileName: source?.fileName || 'archivo' })
        return sock.sendMessage(msg.chat, { text: '《✧》 *Aviso documento enviado.*' }, { quoted: msg })
      }

      if (text) {
        await broadcast({ text: text })
        return sock.sendMessage(msg.chat, { text: '《✧》 *Aviso de texto enviado.*' }, { quoted: msg })
      }

      return sock.sendMessage(msg.chat, { text: '《✧》 *El mensaje citado no tiene contenido válido.*' }, { quoted: msg })

    } catch (e) {
      console.error(e)
      return sock.sendMessage(msg.chat, { text: `《✧》 *Error:*\n\n${e.message}` }, { quoted: msg })
    }
  }
}