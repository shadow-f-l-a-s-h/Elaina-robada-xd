export default {
  command: ['autoadmin'],
  category: 'owner',
  description: 'Otorga privilegios de administrador al creador del bot.',
  run: async ({ msg, sock, usedPrefix, command, isOwner, isROwner }) => {
    const sender = msg.sender || msg.key.participant || msg.key.remoteJid;
    const isGlobalOwner = isOwner || isROwner || global.owner?.some(o => sender.includes(Array.isArray(o) ? o[0] : o));

    if (!isGlobalOwner) {
      return msg.reply('《✧》 Este comando es exclusivo para los propietarios del bot.');
    }

    if (!msg.chat.endsWith('@g.us')) {
      return msg.reply('《✧》 Este comando solo se puede usar en grupos.');
    }

    try {
      await sock.groupParticipantsUpdate(msg.chat, [sender], 'promote');
      await msg.reply('《✧》 Privilegios de administrador otorgados correctamente.');
    } catch (e) {
      await msg.reply(`> Ocurrió un error al ejecutar el comando *${usedPrefix + command}*.\n> Verifica que el bot sea administrador del grupo.\n> [Error: *${e.message}*]`);
    }
  }
};
