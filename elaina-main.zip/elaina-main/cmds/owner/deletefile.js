import fetch from 'node-fetch';

// CONFIGURACIÓN DE TU REPOSITORIO DE GITHUB
const GITHUB_TOKEN = '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'; // Personal Access Token
const REPO_OWNER = 'mai1206-art';                             // Usuario de GitHub
const REPO_NAME = 'elaina';                                   // Nombre del repositorio
const BRANCH = 'main';                                        // Rama principal

export default {
  command: ['del', 'deletefile', 'eliminar', 'rm'],
  category: 'owner',
  description: 'Elimina un archivo del repositorio de GitHub desde WhatsApp.',
  isOwner: true, // Manejo nativo de permisos del bot
  run: async ({ sock, msg, usedPrefix, command, text }) => {

    // Menú interactivo de ayuda si el usuario manda el comando vacío
    if (!text || !text.trim()) {
      const menuHelp = `🗑️ *MENÚ Y GUÍA DE ELIMINACIÓN DE ARCHIVOS* 🗑️

Usa este comando para eliminar archivos de tu repositorio en GitHub.

━━━━━━━━━━━━━━━━━━━━━━
📌 *Sintaxis:*
> \`${usedPrefix + command} <ruta_del_archivo>\`

📌 *Ejemplos de uso:*
> \`${usedPrefix + command} cmds/utils/test.js\`
> \`${usedPrefix + command} plugins/games/ruleta.js\`
━━━━━━━━━━━━━━━━━━━━━━
⚠️ *Atención:* Esta acción eliminará el archivo del repositorio remoto. Para borrar una carpeta completa, debes eliminar todos sus archivos internos.`;

      return msg.reply(menuHelp);
    }

    await msg.react('⏳');

    try {
      const targetPath = text.trim().replace(/^\/+|\/+$/g, '');

      // 1. Obtener la información del archivo para extraer su SHA (Requisito de la API de GitHub)
      const getUrl = `https://api.github.com/repos/${REPO_OWNER}/${REPO_NAME}/contents/${targetPath}?ref=${BRANCH}`;
      
      const getResponse = await fetch(getUrl, {
        headers: {
          'Authorization': `token ${GITHUB_TOKEN}`,
          'Accept': 'application/vnd.github.v3+json',
          'User-Agent': 'WhatsApp-Bot-Script'
        }
      });

      const getData = await getResponse.json();

      if (getResponse.status === 404) {
        await msg.react('❌');
        return msg.reply(`❌ *Archivo no encontrado:*\n> La ruta \`${targetPath}\` no existe en el repositorio.`);
      }

      if (Array.isArray(getData)) {
        await msg.react('⚠️');
        return msg.reply(`⚠️ *Error:* \`${targetPath}\` es una carpeta, no un archivo.\n\nIndica la ruta exacta del archivo que deseas borrar dentro de esa carpeta.`);
      }

      // 2. Ejecutar la petición DELETE a GitHub enviando el SHA del archivo
      const deleteUrl = `https://api.github.com/repos/${REPO_OWNER}/${REPO_NAME}/contents/${targetPath}`;
      
      const deleteResponse = await fetch(deleteUrl, {
        method: 'DELETE',
        headers: {
          'Authorization': `token ${GITHUB_TOKEN}`,
          'Accept': 'application/vnd.github.v3+json',
          'Content-Type': 'application/json',
          'User-Agent': 'WhatsApp-Bot-Script'
        },
        body: JSON.stringify({
          message: `build: eliminar archivo ${targetPath} vía WhatsApp`,
          sha: getData.sha,
          branch: BRANCH
        })
      });

      const deleteData = await deleteResponse.json();

      if (deleteResponse.status === 200) {
        await msg.react('✅');
        let responseMsg = `🗑️ *ARCHIVO ELIMINADO EN GITHUB*\n\n`;
        responseMsg += `📁 *Ruta eliminada:* \`${targetPath}\`\n`;
        responseMsg += `🔗 *Commit SHA:* \`${deleteData.commit.sha.substring(0, 7)}\`\n\n`;
        responseMsg += `📌 *Paso final:* Ejecuta tu comando \`.fix\` para actualizar el bot localmente.`;

        await msg.reply(responseMsg);
      } else {
        await msg.react('❌');
        await msg.reply(`❌ *Error al borrar en GitHub:*\n> ${deleteData.message || 'Error desconocido.'}`);
      }

    } catch (error) {
      await msg.react('❌');
      await msg.reply(`⚠️ *Excepción durante la ejecución:*\n> ${error.message}`);
    }
  }
};