import { promises as fsp } from 'fs'
import os from 'os'
import path from 'path'
import { spawn } from 'child_process'

export default {
  command: ['hd', 'enhance', 'remini'],
  category: 'utils',
  description: 'Mejorar la calidad de una imagen.',
  run: async ({ msg, sock, usedPrefix, command }) => {
    try {
      const q = msg.quoted || msg
      const mime = q?.mimetype || q?.msg?.mimetype || ''
      if (!mime) return msg.reply(`《✧》 Responde a una *imagen* con:\n${usedPrefix + command}`)
      
      const buffer = await q.download?.()
      if (!buffer) return msg.reply('《✧》 No se pudo descargar la imagen')

      await sock.reply(msg.chat, '《✧》 Mejorando imagen...', msg)
      const result = await vectorinkEnhance(buffer)
      
      if (!result?.ok) {
        return msg.reply(`《✧》 No se pudo mejorar (${result?.error || 'error'})`)
      }
      await sock.sendMessage(msg.chat, { image: result.buffer }, { quoted: msg })
    } catch (e) {
      console.error(e)
      await msg.reply(`> Error en *${usedPrefix + command}*: ${e.message}`)
    }
  }
}

function runFfmpeg(args) {
  return new Promise((res, rej) => {
    const p = spawn('ffmpeg', args)
    let err = ''
    p.stderr.on('data', d => err += d)
    p.on('close', c => c === 0 ? res() : rej(new Error(err)))
  })
}

async function vectorinkEnhance(inputBuf) {
  const API = 'https://us-central1-vector-ink.cloudfunctions.net/upscaleImage'
  const tmpDir = path.join(os.tmpdir(), 'vectorink')
  await fsp.mkdir(tmpDir, { recursive: true })
  
  try {
    const b64 = inputBuf.toString('base64')
    const response = await fetch(API, {
      method: 'POST',
      headers: { 'content-type': 'application/json', 'origin': 'https://vectorink.io', 'referer': 'https://vectorink.io/' },
      body: JSON.stringify({ data: { image: b64 } })
    })
    const j = await response.json()
    const inner = JSON.parse(j.result)
    const webpBuf = Buffer.from(inner.image.b64_json, 'base64')
    
    const inPath = path.join(tmpDir, `in_${Date.now()}.webp`)
    const outPath = path.join(tmpDir, `out_${Date.now()}.png`)
    await fsp.writeFile(inPath, webpBuf)
    await runFfmpeg(['-y', '-i', inPath, '-frames:v', '1', outPath])
    const png = await fsp.readFile(outPath)
    await fsp.unlink(inPath).catch(()=>{})
    await fsp.unlink(outPath).catch(()=>{})
    return { ok: true, buffer: png }
  } catch (e) {
    return { ok: false, error: e.message }
  }
}