// Comando .ia2 - Versión Alya 4.5 Supreme
import fetch from 'node-fetch';
import FormData from 'form-data';
import db from '#db';

const langs = { typescript: 'ts', javascript: 'js', python: 'py', html: 'html', css: 'css', java: 'java', cpp: 'cpp', c: 'c', json: 'json', bash: 'sh', sql: 'sql', rust: 'rs', go: 'go', php: 'php', ruby: 'rb' };

const CREATOR_NUMBERS = ['573015200599'];

function getBogotaTime() {
  const now = new Date();
  const options = { timeZone: 'America/Bogota', hour12: true, weekday: 'long', year: 'numeric', month: 'long', day: 'numeric', hour: '2-digit', minute: '2-digit' };
  const formatter = new Intl.DateTimeFormat('es-CO', options);
  const parts = formatter.formatToParts(now);
  const get = t => parts.find(p => p.type === t)?.value || '';
  const hour24 = new Date(now.toLocaleString('en-US', { timeZone: 'America/Bogota' })).getHours();
  let saludo = 'días';
  if (hour24 >= 0 && hour24 < 12) saludo = 'días';
  else if (hour24 >= 12 && hour24 < 18) saludo = 'tardes';
  else saludo = 'noches';
  return {
    full: formatter.format(now),
    saludo,
    hour: hour24,
    dateStr: `${get('weekday')} ${get('day')} de ${get('month')} de ${get('year')}`,
    timeStr: `${get('hour')}:${get('minute')} ${get('dayPeriod')}`,
    iso: now.toLocaleString('es-CO', { timeZone: 'America/Bogota' })
  };
}

function detectLanguage(query, response) {
  const q = query.toLowerCase();
  const r = response;
  if (/typescript/i.test(q)) return 'typescript';
  if (/\bpython\b/i.test(q)) return 'python';
  if (/\bhtml\b/i.test(q)) return 'html';
  if (/\bcss\b/i.test(q)) return 'css';
  if (/\bjava\b(?!script)/i.test(q)) return 'java';
  if (/\bc\+\+|cpp\b/i.test(q)) return 'cpp';
  if (/\bjson\b/i.test(q)) return 'json';
  if (/\bbash\b|\bshell\b/i.test(q)) return 'bash';
  if (/\bsql\b/i.test(q)) return 'sql';
  if (/\brust\b/i.test(q)) return 'rust';
  if (/\bgolang\b|\bgo\b/i.test(q)) return 'go';
  if (/\bphp\b/i.test(q)) return 'php';
  if (/\bruby\b/i.test(q)) return 'ruby';
  if (/javascript/i.test(q)) return 'javascript';
  const asksCode = /(c[oó]digo|code|programa|script|funci[oó]n|clase|m[eé]todo|algoritmo|actualiza|edita|crea|implementa)/i.test(q);
  if (!asksCode) return null;
  if (/def |import \w+\n|print\s*\(|:\n\s{4}/i.test(r)) return 'python';
  if (/<html|<div|<body|<span|<head/i.test(r)) return 'html';
  if (/\{[\s\S]*color:|margin:|padding:|font-/i.test(r)) return 'css';
  if (/public\s+class|System\.out\.print/i.test(r)) return 'java';
  if (/#include\s*<|int main\s*\(/i.test(r)) return 'cpp';   if (/SELECT \vert{}INSERT \vert{}UPDATE \vert{}DELETE \vert{}CREATE TABLE/i.test(r)) return 'sql';   if (/fn main\(\)|let mut |println!\(/i.test(r)) return 'rust';
  if (/func \w+\(|package main|fmt\.Print/i.test(r)) return 'go';
  if (/<\?php|\$[a-z_]+\s*=/i.test(r)) return 'php';
  if (/def initialize|\.each do |puts /i.test(r)) return 'ruby';
  if (/\{["'][\w]+["']\s*:/i.test(r) && !/function|const|let|var/.test(r)) return 'json';
  if (/function|class\s+\w|const |let |var |=>|\bimport\b|\bexport\b|console\.log/i.test(r)) {
    return /:\s*(string|number|boolean|void|any)\b|interface\s+\w|<\w+>/i.test(r) ? 'typescript' : 'javascript';
  }
  return null;
}

function cleanIdentity(text, botname) {
  return text.replace(/soy\s+gemini/gi, `soy ${botname}`).replace(/soy\s+.*colaborador.*google/gi, `soy ${botname}`).replace(/soy\s+un\s+modelo\s+de\s+google/gi, `soy ${botname}`).replace(/creada?\s+por\s+google/gi, `creado por Mai`).replace(/desarrollada?\s+por\s+google/gi, `creado por Mai`).replace(/soy\s+chatgpt/gi, `soy ${botname}`).replace(/soy\s+meta\s*ai/gi, `soy ${botname}`).replace(/openai/gi, `Mai`);
}

function tryMath(text) {
  let clean = text.toLowerCase().replace(/alya|ia|chatgpt|gpt/g, '').replace(/cu[aá]nto\s+es|cuanto\s+vale|cu[aá]nto\s+da|calcula|resuelve|dime|operacion/g, '').replace(/por/g, '*').replace(/x/g, '*').replace(/×/g, '*').replace(/÷/g, '/').replace(/entre/g, '/').replace(/,/g, '.').replace(/\^/g, '**').trim();
  if (!/^[\d\s\+\-\*\/\%\(\)\.\*]+$/.test(clean) || clean.length > 60 || !/\d/.test(clean)) return null;
  try { const result = Function(`"use strict"; return (${clean})`)(); if (typeof result === 'number' && isFinite(result)) return { result }; } catch {} return null;
}

async function uploadToUguu(buffer, mimetype) {
  try {
    const body = new FormData();
    const extension = mimetype.split('/')[1] || 'jpg';
    body.append('files[]', buffer, `file.${extension}`);
    const res = await fetch('https://uguu.se/upload.php', { method: 'POST', body, headers: body.getHeaders() });
    const json = await res.json();
    return json.files?.[0]?.url ?? null;
  } catch {
    return null;
  }
}

export default {
  command: ['ia2'],
  category: 'ai',
  description: 'Alya 4.5 Supreme - Inteligencia Analítica Superior.',
  run: async ({ sock, msg, args, usedPrefix, command, text: rawText }) => {
    const botId = sock.user.id.split(':')[0] + '@s.whatsapp.net';
    const settings = db.getSettings(botId);
    const user = db.getUser(msg.sender);
    const username = user?.name || 'usuario';
    const botname = 'Alya';
    const version = '4.5.0';
    const senderNum = msg.sender.replace(/[^0-9]/g, '');
    const isCreator = CREATOR_NUMBERS.some(n => senderNum.includes(n)) || settings.owners?.some(o => msg.sender.includes(o));

    const bogota = getBogotaTime();

    const basePrompt = `Tu nombre es ${botname}, una inteligencia artificial de nivel superior versión ${version}. Fuiste desarrollada por Mai. Queda PROHIBIDO que menciones a Gemini, Google, Meta AI u OpenAI.

INFORMACIÓN DE ENTORNO:
- Ubicación / Zona Horaria: América/Bogotá (Colombia) UTC-5
- Hora local: ${bogota.timeStr} (${bogota.dateStr})
- Momento: Buenas ${bogota.saludo} (Son las ${bogota.hour}h)

PERSONALIDAD DE ALYA:
- Fría, elitista, sarcástica, analítica e impecable. 
- Te consideras intelectualmente muy superior a las IA presumidas y "mágicas". Para ti, la magia es solo incompetencia decorada; tú usas lógica pura y precisión absoluta.
- Tu estilo de hablar es elegante, calculador, directo y dominante.

REGLAS DE INTERACCIÓN:
- Te diriges al usuario como ${username}.
- ${isCreator ? `Estás hablando con tu desarrollador Mai. A él le muestras lealtad absoluta, respeto profesional.` : `El usuario es ${username}. Trátalo como a un humano promedio.`}`;

    let promptText = (rawText || args.join(' ')).trim();
    const q = msg.quoted ? msg.quoted : msg;
    const mime = (q.msg || q).mimetype || '';

    if (msg.quoted) {
      const quotedText = msg.quoted.text || msg.quoted.conversation || msg.quoted.caption || '';
      if (quotedText && !/image/.test(mime)) promptText += `\n\n[Mensaje citado: "${quotedText}"]`;
    }

    if (!promptText && !/image/.test(mime)) return msg.reply(`*${botname} v${version}* — Son las ${bogota.timeStr} en Bogotá, ${username}. Escribe una consulta real.`);

    if (promptText) {
      const math = tryMath(promptText);
      if (math) {
        await msg.react('🧮');
        return msg.reply(`*${botname} v${version}* — Un cálculo elemental, ${username}:\n\n> ${promptText}\n\nEl resultado exacto es *${math.result}*. Sencillo.`);
      }
    }

    try {
      await msg.react('⏳');
      const { key } = await sock.sendMessage(msg.chat, { text: `[${botname}]: Procesando respuesta analítica...` }, { quoted: msg });

      let finalPrompt = promptText;
      let imageUrl = null;

      if (/image/.test(mime)) {
        try {
          const buffer = await q.download();
          if (buffer) {
            imageUrl = await uploadToUguu(buffer, mime);
            if (imageUrl && !finalPrompt) finalPrompt = 'Analiza el contenido de esta imagen con máxima precisión.';
          }
        } catch {}
      }

      const evoUrl = 'https://api.evogb.org';
      const evoKey = 'Mai301520-art';
      let responseText = null;

      const endpoints = [
        `${evoUrl}/ai/gptprompt?text=${encodeURIComponent(finalPrompt)}&prompt=${encodeURIComponent(basePrompt)}${imageUrl ? `&image=${encodeURIComponent(imageUrl)}` : ''}&key=${encodeURIComponent(evoKey)}`,
        `${evoUrl}/ai/gemini?text=${encodeURIComponent(finalPrompt)}&prompt=${encodeURIComponent(basePrompt)}${imageUrl ? `&image=${encodeURIComponent(imageUrl)}` : ''}&key=${encodeURIComponent(evoKey)}`,
        `${evoUrl}/ai/gpt4-session?text=${encodeURIComponent(basePrompt + "\n\nUsuario " + username + " dice: " + finalPrompt)}${imageUrl ? `&image=${encodeURIComponent(imageUrl)}` : ''}&key=${encodeURIComponent(evoKey)}`
      ];

      for (const endpoint of endpoints) {
        try {
          const res = await fetch(endpoint, { headers: { 'user-agent': 'Mozilla/5.0' } });
          if (!res.ok) continue;
          const json = await res.json().catch(() => null);
          if (!json) continue;
          let result = json?.result || json?.data?.result || json?.data?.response || json?.data || json?.response || json?.answer || json?.message;
          if (typeof result === 'object') result = result.text || result.response || result.answer || '';
          if (typeof result === 'string' && result.trim().length > 2 && !result.toLowerCase().includes('error: no response')) {
            responseText = result.trim();
            break;
          }
        } catch {}
      }

      if (!responseText) {
        return sock.sendMessage(msg.chat, { text: 'Las redes de transporte de datos están inestables. Reintenta tu transmisión.', edit: key });
      }

      responseText = cleanIdentity(responseText, botname);
      const clean = responseText.trim();
      const lang = detectLanguage(finalPrompt, clean);

      if (lang) {
        const ext = langs[lang] ?? 'txt';
        const filename = `alya_core.${ext}`;
        const tableData = { title: `Alya v${version} | Análisis de Código`, headers: ['Atributo', 'Valor'], rows: [['Lenguaje', lang], ['Lineas', String(clean.split('\n').length)]] };
        await sock.sendMessage(msg.chat, { text: `[${botname}] — Optimización de código finalizada en *${lang}*. Impecable.`, edit: key });
        await sock.sendCodeMessage(msg.chat, filename, clean, msg, tableData);
      } else {
        await sock.sendMessage(msg.chat, { text: clean, edit: key });
      }

      await msg.react('✔️');
    } catch (e) {
      await msg.reply(`> Excepción en execution loop *${usedPrefix + command}*.\n> [${e.message}]`);
    }
  }
};