import db from "#db"

export default {
  command: ['report', 'reporte', 'sug', 'suggest', 'r'],
  category: 'info',
  run: async ({ msg, sock, args, command, text, usedPrefix: prefix }) => {
    const targets = ['573015200599@s.whatsapp.net', '584122228574@s.whatsapp.net']
    const sender = msg.sender
    const now = Date.now()

    try {
      if (command === 'r') {
        const isOwner = global.owner?.some(num => `${num}@s.whatsapp.net` === sender) || targets.includes(sender)
        if (!isOwner) return msg.reply('《✤》 Este comando es exclusivo para responder sugerencias/reportes.')

        const quoted = msg.message?.extendedTextMessage?.contextInfo?.quotedMessage
        const quotedText = quoted?.conversation || quoted?.extendedTextMessage?.text || quoted?.imageMessage?.caption || ''
        
        const matchNum = quotedText.match(/wa\.me\/(\d+)/)
        const matchGroup = quotedText.match(/Grupo\*\s*\n>\s*([^\n\r]+)/)

        if (!matchNum || !matchNum[1]) {
          return msg.reply('《✤》 Debes responder al mensaje del reporte/sugerencia original para que el usuario reciba la respuesta.')
        }

        const targetUser = `${matchNum[1]}@s.whatsapp.net`
        const replyText = args.join(' ').trim()

        if (!replyText) {
          return msg.reply('《✤》 Escribe el mensaje de respuesta para el usuario.')
        }

        const responseMsg = `✿ *Respuesta de Developers:*\n\n> ${replyText}`
        const destination = matchGroup && matchGroup[1].trim().includes('@g.us') ? matchGroup[1].trim() : targetUser

        await sock.sendMessage(destination, {
          text: responseMsg,
          mentions: [targetUser]
        }, { quoted: msg })

        return msg.reply('《✤》 Respuesta enviada correctamente al grupo.')
      }

      const userData = await db.getUser(sender) || {}
      let cooldown = userData.sugCooldown || 0

      if (cooldown > now + 30 * 1000) {
        cooldown = 0
      }

      if (cooldown > now) {
        return msg.reply(`《✤》 Espera *${msToTime(cooldown - now)}* para volver a usar este comando.`)
      }

      const mensajeTexto = args.join(' ').trim()
      if (!mensajeTexto) {
        return msg.reply('《✤》 Debes escribir el reporte o sugerencia.')
      }
      if (mensajeTexto.length < 10) {
        return msg.reply('✿ Tu mensaje es demasiado corto. Mínimo 10 caracteres.')
      }

      const isReport = ['report', 'reporte'].includes(command)
      const tipo = isReport ? '🆁ҽ𝕡σɾƚҽ' : '🆂մց𝕖ລະ𝚗cíᥲ'
      const displayName = msg.pushName || 'Usuario desconocido'
      const numero = sender.split('@')[0]
      const currentChat = msg.chat
      const fechaLocal = new Date().toLocaleDateString('es-MX', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' })

      const reportMsg = 
        `🫗۫᷒ᰰ⃘ׅ᷒  ۟　\`${tipo}\`　ׅ　ᩡ\n\n` +
        `𖹭  ׄ  ְ 🍒 *Nombre*\n> ${displayName}\n\n` +
        `𖹭  ׄ  ְ 🦩 *Número*\n> wa.me/${numero}\n\n` +
        `𖹭  ׄ  ְ 💬 *Grupo*\n> ${currentChat}\n\n` +
        `𖹭  ׄ  ְ 🌱 *Fecha*\n> ${fechaLocal}\n\n` +
        `𖹭  ׄ  ְ 🍓 *Mensaje*\n> ${mensajeTexto}`

      for (const target of targets) {
        try {
          await sock.sendMessage(target, { text: reportMsg }, { quoted: msg })
        } catch (e) {
          console.error(`Error enviando a ${target}:`, e)
        }
      }

      userData.sugCooldown = now + 30 * 1000
      await db.updateUser(sender, 'sugCooldown', userData.sugCooldown)

      return msg.reply(`《✤》 Gracias por tu ${isReport ? 'reporte' : 'sugerencia'}\n\n> Tu mensaje fue enviado correctamente a los moderadores.`)

    } catch (err) {
      console.error(err)
      return msg.reply(typeof msgglobal !== 'undefined' ? msgglobal : '❌ Ocurrió un error inesperado.')
    }
  }
}

const msToTime = (duration) => {
  const seconds = Math.floor((duration / 1000) % 60)
  const minutes = Math.floor((duration / (1000 * 60)) % 60)
  const hours = Math.floor((duration / (1000 * 60 * 60)) % 24)
  const days = Math.floor(duration / (1000 * 60 * 60 * 24))

  const parts = []
  if (days > 0) parts.push(`${days} día${days > 1 ? 's' : ''}`)
  if (hours > 0) parts.push(`${hours} hora${hours > 1 ? 's' : ''}`)
  if (minutes > 0) parts.push(`${minutes} minuto${minutes > 1 ? 's' : ''}`)
  parts.push(`${seconds} segundo${seconds > 1 ? 's' : ''}`)

  return parts.join(', ')
    }
