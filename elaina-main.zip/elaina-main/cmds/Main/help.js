import db from "#db"
import { prepareWAMessageMedia } from 'baileys'
import moment from 'moment-timezone'
import os from 'os'
import { commands } from '../../lib/system/comandos.js'

export default {
  command: ['allmenu', 'help', 'menu'],
  category: 'info',
  run: async ({ msg, sock, args, command, usedPrefix: prefix }) => {
    try {
      const botTime = moment().tz('America/Bogota').format('DD MMM YYYY, hh:mm A')

      const botId = sock?.user?.id.split(':')[0] + '@s.whatsapp.net' || ''
      const botSettings = await db.getSettings(botId)
      const { namebot = '', namebot2 = '', banner = '', owner = '' } = botSettings
      
      const link = 'https://api.evogb.org'
      const isOficialBot = botId === (global?.sock?.user?.id?.split(':')[0] + '@s.whatsapp.net')
      const botType = isOficialBot ? 'Owner' : 'Sub Bot'
      const platform = `${os.type()} ${os.release()} ${os.arch()}`

      const userr = await db.getUser()
      const own = await db.getUser(owner)
      const dev = owner && !isNaN(owner.replace('@s.whatsapp.net', '')) ? own.name : owner || 'Oculto'

      let menu = `> *¡ʜᴏʟᴀ!* ${msg.pushName}, como está tu día?, mucho gusto mi nombre es *${namebot2}* ʚ♡⃛ɞ(ू•ᴗ•ू❁)*\n\n` +
      `   ⌒࣪᷼⏜͡  ۪  ࿚ꨪᰰ࿙  ࣭࣪⢏࣭۟⢢࣭ׄ᎐፝֟᎐࣭ׄ⡔࣭۟⡹࣭ׄ  ࿚ꨪᰰ࿙  ۪  ͡⏜ׄ᷼⌒\n\n` +
      `: ̗̀〄 *ᴅᴇᴠᴇʟᴏᴘᴇʀ ::* ${dev}\n` +
      `: ̗̀ꕥ *ᴛɪᴘᴏ ::* ${botType}\n` +
      `: ̗̀☄︎ *sɪsᴛᴇᴍᴀ/ᴏᴘʀ ::* ${platform}\n\n` +
      `: ̗̀❖ *ᴜsᴇʀs ::* ${(Object.keys(userr).length || 0).toLocaleString()}\n` +
      `: ̗̀❖ *ᴍɪ ᴛɪᴇᴍᴘᴏ ::* ${botTime} (Colombia)\n` +
      `: ̗̀❖ *ᴜʀʟ ::* ${link}\n\n` +
      `   ⌒࣪᷼⏜͡  ۪  ࿚ꨪᰰ࿙  ࣭࣪⢏࣭۟⢢࣭ׄ᎐፝֟᎐࣭ׄ⡔࣭۟⡹࣭ׄ  ࿚ꨪᰰ࿙  ۪  ͡⏜ׄ᷼⌒\n\n` +
      `⋆｡ﾟ☁︎ ｡° *ᴄᴏᴍ꯭ᴀ꯭ɴᴅᴏs* ﾟ｡˚₊ 𓂃\n`

      const catArg = args[0]?.toLowerCase()
      const cats = {}
      commands.forEach(c => (cats[c.category || 'otros'] ??= []).push(c))

      if (catArg && !cats[catArg]) return msg.reply(`《✤》 La categoría *${catArg}* no fue encontrada.`)

      for (const [cat, cmds] of Object.entries(cats)) {
        if (catArg && cat.toLowerCase() !== catArg) continue
        menu += `\n╭╼ׅࣶ፝֟╾╌ֵ╾͜─ํ͜┈ְ ࣭࣪⢏࣭ࣧ⢢࣭ׄ᎐፝֟͟͝᎐࣭ׄ⡔࣭ࣧ⡹࣭࣭ׄ࣪ ְ┈ํ͜─͜╼ꨪᰰ╾࣮╌╼ࣶׅ፝֟╾╮\n│❀ *${cat.charAt(0).toUpperCase() + cat.slice(1)} ☆(ﾉ◕ヮ◕)ﾉ*\n├╾ׅ╴ׂ╌╶ׅ╌ׂ─ 〫─ׂ┄ׅ╴ׂ╌ׅ╶╼.  ╾ׅ╴ׂ╌╶ׅ╌ׂ\n`
        cmds.forEach(cmd => {
          menu += `│✿ ${cmd.alias.map(a => prefix + a.split(/[\/#!+.\-]+/).pop().toLowerCase()).join(' › ')} ${cmd.uso ? `+ ${cmd.uso}` : ''}\n> ✺ ${cmd.desc}\n`
        })
        menu += `╰╼ׅࣶ፝֟╾╌ֵ╾͜─ํ͜┈ְ ࣭࣪⢏࣭ࣧ⢢࣭ׄ᎐፝֟͟͝᎐࣭ׄ⡔࣭ࣧ⡹࣭ׄ ְ┈ํ͜─͜╼ꨪᰰ╾࣮╌╼ࣶׅ፝֟╾╯ \n`
      }

      menu += `\n> *${namebot2} desarrollado por 𝙻𝚘𝙵𝚒 ☕︎ 𝚃𝙴𝙰𝙼™ * ૮(˶ᵔᵕᵔ˶)ა`

      const isVideo = /\.(mp4|gif|webm)$/i.test(banner)
      const ctx = { mentionedJid: null, isForwarded: false }

      if (isVideo) {
        await sock.sendMessage(msg.chat, { video: { url: banner }, caption: menu.trim(), contextInfo: ctx }, { quoted: msg })
      } else {
        const preview = link && banner ? await prepareWAMessageMedia({ image: { url: banner } }, { upload: sock.waUploadToServer, mediaTypeOverride: 'thumbnail-link' }).then(m => ({ 'canonical-url': link, 'matched-text': link, title: namebot, description: `${namebot2}, Built With 💜 By 𝙻𝚘𝙵𝚒 ☕︎ 𝚃𝙴𝙰𝙼™ `, jpegThumbnail: m.imageMessage?.jpegThumbnail ? Buffer.from(m.imageMessage.jpegThumbnail) : undefined, highQualityThumbnail: m.imageMessage || undefined })) : undefined
        await sock.sendMessage(msg.chat, { text: menu.trim(), linkPreview: preview, contextInfo: ctx }, { quoted: msg })
      }
    } catch (e) {
      await msg.reply(typeof msgglobal !== 'undefined' ? msgglobal : '❌ Ocurrió un error al generar el menú.')
    }
  }
}
