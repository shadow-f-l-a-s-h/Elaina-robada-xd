import db from '#db';
export default {
  command: ['setpasatiempo', 'sethobby'],
  category: 'profile',
  description: 'Establecer tu pasatiempo.',
  run: async ({ msg, args, usedPrefix }) => {
    const user = db.getUser(msg.sender);
    const input = args.join(' ').trim();    
    const pasatiemposDisponibles = [
      '📚 Leer', '✍️ Escribir', '🎤 Cantar', '💃 Bailar', '🎮 Jugar', 
      '🎨 Dibujar', '🍳 Cocinar', '✈️ Viajar', '🏊 Nadar', '📸 Fotografía',
      '🎧 Escuchar música', '🏀 Deportes', '🎬 Ver películas', '🌿 Jardinería',
      '🧵 Manualidades', '🎲 Juegos de mesa', '🏋️‍♂️ Gimnasio', '🚴 Ciclismo',
      '🎯 Tiro con arco', '🍵 Ceremonia del té', '🧘‍♂️ Meditación', '🎪 Malabares',
      '🛠️ Bricolaje', '🎹 Tocar instrumentos', '🐶 Cuidar mascotas', '🌌 Astronomía',
      '♟️ Ajedrez', '🍷 Catación de vinos', '🛍️ Compras', '🏕️ Acampar',
      '🎣 Pescar', '📱 Tecnología', '🎭 Teatro', '🍽️ Gastronomía', '🏺 Coleccionar',
      '✂️ Costura', '🧁 Repostería', '📝 Blogging', '🚗 Automóviles', '🧩 Rompecabezas',
      '🎳 Bolos', '🏄 Surf', '⛷️ Esquí', '🎿 Snowboard', '🤿 Buceo', '🏹 Tiro al blanco',
      '🧭 Orientación', '🏇 Equitación', '🎨 Pintura', '📊 Invertir', '🌡️ Meteorología',
      '🔍 Investigar', '💄 Maquillaje', '💇‍♂️ Peluquería', '🛌 Dormir', '🍺 Cervecería',
      '🪓 Carpintería', '🧪 Experimentos', '📻 Radioafición', '🗺️ Geografía', '💎 Joyería',
      'Otro 🌟'
    ];    
    if (!input) {
      let lista = '🎯 *Elige un pasatiempo:*\n\n';
      pasatiemposDisponibles.forEach((pasatiempo, index) => {
        lista += `${index + 1}) ${pasatiempo}\n`;
      });
      lista += `\n*Ejemplos:*\n${usedPrefix}setpasatiempo 1\n${usedPrefix}setpasatiempo Leer\n${usedPrefix}setpasatiempo "Otro 🌟"`;
      return msg.reply(lista);
    }    
    let pasatiempoSeleccionado = '';
    if (/^\d+$/.test(input)) {
      const index = parseInt(input) - 1;
      if (index >= 0 && index < pasatiemposDisponibles.length) {
        pasatiempoSeleccionado = pasatiemposDisponibles[index];
      } else {
        return msg.reply(`《✧》 Número inválido. Selecciona un número entre 1 y ${pasatiemposDisponibles.length}`);
      }
    } else {
      const inputLimpio = input.replace(/[^\w\s]/g, '').toLowerCase().trim();
      const encontrado = pasatiemposDisponibles.find(p => p.replace(/[^\w\s]/g, '').toLowerCase().includes(inputLimpio));
      if (encontrado) {
        pasatiempoSeleccionado = encontrado;
      } else {
        return msg.reply('《✧》 Pasatiempo no encontrado. Usa el comando sin argumentos para ver la lista disponible.');
      }
    }    
    if (user.pasatiempo === pasatiempoSeleccionado) {
      return msg.reply(`《✧》 Ya tienes establecido este pasatiempo: *${user.pasatiempo}*`);
    }    
    db.updateUser(msg.sender, 'pasatiempo', pasatiempoSeleccionado);
    return msg.reply(`✐ Se ha establecido tu pasatiempo:\n> *${pasatiempoSeleccionado}*`);
  },
};
