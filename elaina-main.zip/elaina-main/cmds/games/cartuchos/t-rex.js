await (async () => {
const crypto = require('crypto');

const fs = require('fs');
const path = require('path');

const SPRITE_PATH = [
  path.resolve(process.cwd(), 'cmds/games/cartuchos/trex-sprite.png'),
  path.resolve(process.cwd(), 'trex-sprite.png')
].find(p => fs.existsSync(p));
if (!SPRITE_PATH) throw new Error('Falta trex-sprite.png en cmds/games/cartuchos/');
const SPRITE_B64 = fs.readFileSync(SPRITE_PATH).toString('base64');

const HTML = `<div style="width:100%;max-width:420px;margin:0 auto;background:#0f172a;font-family:Arial,sans-serif;padding:12px;border-radius:16px;text-align:center;box-sizing:border-box;color:white;user-select:none;touch-action:none">
<div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:10px">
  <div style="color:#f1f5f9;font-weight:900;font-size:18px;letter-spacing:1px">🦖 T-REX RUNNER</div>
  <div style="background:#1e293b;padding:4px 10px;border-radius:20px;display:flex;gap:8px">
    <span style="color:#94a3b8;font-size:10px">SCORE <b id="score" style="color:white">00000</b></span>
    <span style="color:#94a3b8;font-size:10px">HIGH <b id="highScore" style="color:#f59e0b">00000</b></span>
    <button id="muteBtn" style="background:none;border:none;color:white;font-size:14px;cursor:pointer;padding:0;margin-left:4px">🔊</button>
  </div>
</div>

<canvas id="c" width="360" height="150" style="background:#ffffff;display:block;border-radius:8px;border:2px solid #334155;width:100%;height:auto;image-rendering:pixelated"></canvas>

<div style="display:grid;grid-template-columns:1fr 1fr;gap:8px;max-width:320px;margin:12px auto 0">
  <button id="duck" style="height:48px;border-radius:10px;background:#1e293b;color:white;border:1px solid #334155;font-size:16px;font-weight:bold">▼ AGACHAR</button>
  <button id="jump" style="height:48px;border-radius:10px;background:#3b82f6;color:white;border:none;font-size:16px;font-weight:bold">▲ SALTAR</button>
</div>
<div style="color:#64748b;font-size:10px;margin-top:8px">Toca SALTAR para jugar</div>

<script>
(function(){
const canvas=document.getElementById('c'), ctx=canvas.getContext('2d');
const scoreEl=document.getElementById('score'), highEl=document.getElementById('highScore');
const jumpBtn=document.getElementById('jump'), duckBtn=document.getElementById('duck');
const muteBtn=document.getElementById('muteBtn');

// --- SISTEMA DE AUDIO ROBUSTO (IDÉNTICO AL DE TETRIS) ---
let audioCtx = null;
let isMuted = false;

function initAudio(){
  if(!audioCtx){
    const AudioContext = window.AudioContext || window.webkitAudioContext;
    if(AudioContext){
      audioCtx = new AudioContext();
    }
  }
  if(audioCtx && audioCtx.state === 'suspended'){
    audioCtx.resume();
  }
}

function toggleMute(){
  isMuted = !isMuted;
  muteBtn.textContent = isMuted ? '🔇' : '🔊';
}

muteBtn.onclick = (e) => {
  e.stopPropagation();
  initAudio();
  toggleMute();
};

function playSound(type) {
  if (isMuted) return;
  initAudio();
  if (!audioCtx) return;
  try {
    const now = audioCtx.currentTime;
    const osc = audioCtx.createOscillator();
    const gain = audioCtx.createGain();
    osc.connect(gain);
    gain.connect(audioCtx.destination);

    if (type === 'jump') {
      osc.type = 'square';
      osc.frequency.setValueAtTime(300, now);
      osc.frequency.exponentialRampToValueAtTime(600, now + 0.15);
      gain.gain.setValueAtTime(0.08, now);
      gain.gain.exponentialRampToValueAtTime(0.001, now + 0.15);
      osc.start(now);
      osc.stop(now + 0.15);
    } else if (type === 'hit') {
      osc.type = 'sawtooth';
      osc.frequency.setValueAtTime(160, now);
      osc.frequency.exponentialRampToValueAtTime(60, now + 0.2);
      gain.gain.setValueAtTime(0.1, now);
      gain.gain.exponentialRampToValueAtTime(0.001, now + 0.2);
      osc.start(now);
      osc.stop(now + 0.2);
    } else if (type === 'score') {
      osc.type = 'sine';
      osc.frequency.setValueAtTime(800, now);
      osc.frequency.setValueAtTime(1200, now + 0.08);
      gain.gain.setValueAtTime(0.06, now);
      gain.gain.exponentialRampToValueAtTime(0.001, now + 0.2);
      osc.start(now);
      osc.stop(now + 0.2);
    }
  } catch(e) {}
}

let lastScoreSound = 0;





const W=360, H=150, GROUND_Y=140; 
const GRAVITY=0.6, JUMP_VELOCITY=-10;
const START_SPEED=3.5, MAX_SPEED=13, SPEED_ACCEL=0.00005;
const TREX_W=44, TREX_H=47, TREX_DUCK_W=59, HORIZON_Y=127;





const SPR = {
  TREX: {x:1678, y:2},
  CACTUS_SMALL: {x:446, y:2},
  CACTUS_LARGE: {x:652, y:2},
  PTERODACTYL: {x:260, y:2},
  HORIZON: {x:2, y:104}
};

let img = new Image();
let imgLoaded = false;
img.onload = () => { imgLoaded = true; draw(); };
img.src = "data:image/png;base64,${SPRITE_B64}";

let highScore=0;
try {
  highScore = parseInt(localStorage.getItem('trex_highscore') || '0', 10);
  if(isNaN(highScore)) highScore = 0;
} catch(e) { highScore = 0; }
highEl.textContent = String(highScore).padStart(5,'0');

let running=false, started=false, gameOver=false;
let speed=START_SPEED, distance=0;
let trexY=GROUND_Y-TREX_H, trexVY=0, jumping=false, ducking=false;
let runFrame=0, runTimer=0;
let obstacles=[];
let nextObstacleGap=0;
let groundX=0;

function resetGame(){
  speed=START_SPEED; distance=0;
  trexY=GROUND_Y-TREX_H; trexVY=0; jumping=false; ducking=false;
  obstacles=[]; nextObstacleGap=randGap();
  groundX=0; runFrame=0; runTimer=0;
  gameOver=false; started=true; running=true;
  lastScoreSound = 0;
}

function randGap(){
  return 220 + Math.random()*180 + speed*8;
}

function spawnObstacle(){
  const r = Math.random();
  if(distance > 400 && r < 0.22){
    obstacles.push({type:'ptero', w:46, h:40, x:W, y:[100,75,50][Math.floor(Math.random()*3)], frame:0, ftimer:0, hb:{ox:4, oy:8, w:38, h:19}});
  } else {
    const small = r < 0.6;
    const bw = small ? 17 : 25, bh = small ? 35 : 50, mult = small ? 4 : 7;
    let size = 1 + Math.floor(Math.random()*3);
    if(size > 1 && speed < mult) size = 1;
    obstacles.push({type: small?'cactusSmall':'cactusLarge', bw:bw, size:size, w:bw*size, h:bh, x:W, y:GROUND_Y-bh, hb:{ox:2, oy:2, w:bw*size-4, h:bh-3}});
  }
}

function jump(){
  initAudio();
  if(!started || gameOver){ resetGame(); return; }
  if(!jumping){
    jumping=true;
    trexVY = JUMP_VELOCITY;
    playSound('jump');
  }
}
function setDuck(v){
  initAudio();
  if(!started || gameOver) return;
  ducking = v && !jumping;
}

jumpBtn.addEventListener('click', (e)=>{ e.stopPropagation(); jump(); });
duckBtn.addEventListener('touchstart', (e)=>{ e.preventDefault(); setDuck(true); }, {passive:false});
duckBtn.addEventListener('touchend', (e)=>{ e.preventDefault(); setDuck(false); }, {passive:false});
duckBtn.addEventListener('mousedown', ()=> setDuck(true));
duckBtn.addEventListener('mouseup', ()=> setDuck(false));
duckBtn.addEventListener('mouseleave', ()=> setDuck(false));
canvas.addEventListener('click', ()=>{ initAudio(); jump(); });

document.addEventListener('keydown', e=>{
  initAudio();
  if(e.key==='ArrowUp' || e.key===' '){ e.preventDefault(); jump(); }
  else if(e.key==='ArrowDown'){ setDuck(true); }
});
document.addEventListener('keyup', e=>{
  if(e.key==='ArrowDown'){ setDuck(false); }
});

function rectsOverlap(ax,ay,aw,ah,bx,by,bw,bh){
  const pad=0;
  return ax+pad < bx+bw-pad && ax+aw-pad > bx+pad && ay+pad < by+bh-pad && ay+ah-pad > by+pad;
}

function update(dt){
  if(!running) return;
  speed = Math.min(MAX_SPEED, speed + SPEED_ACCEL*dt);
  distance += speed*dt/16.6667;

  groundX = (groundX + speed*dt/16.6667) % 1200;

  trexVY += GRAVITY*dt/16.6667;
  trexY += trexVY*dt/16.6667;
  if(trexY >= GROUND_Y-TREX_H){
    trexY = GROUND_Y-TREX_H;
    trexVY = 0;
    jumping = false;
  }

  runTimer += dt;
  if(runTimer > 90){ runTimer=0; runFrame = (runFrame+1)%2; }

  nextObstacleGap -= speed*dt/16.6667;
  if(nextObstacleGap <= 0){
    spawnObstacle();
    nextObstacleGap = randGap();
  }

  const tx = 50, ty = trexY;
  const trexBoxes = ducking
    ? [[tx+1, ty+18, 55, 25]]
    : [[tx+22, ty, 17, 16], [tx+1, ty+18, 30, 25]];

  for(let i=obstacles.length-1;i>=0;i--){
    const o = obstacles[i];
    o.x -= speed*dt/16.6667;
    if(o.type==='ptero'){
      o.ftimer += dt;
      if(o.ftimer>166){ o.ftimer=0; o.frame=(o.frame+1)%2; }
    }
    if(o.x < -80){ obstacles.splice(i,1); continue; }
    for(const b of trexBoxes){
      if(rectsOverlap(b[0], b[1], b[2], b[3], o.x+o.hb.ox, o.y+o.hb.oy, o.hb.w, o.hb.h)){ endGame(); break; }
    }
  }
}

function endGame(){
  running=false; gameOver=true;
  playSound('hit');





  // Personalización de la velocidad del puntaje 
  const finalScore = Math.floor(distance/17.0);
  if(finalScore > highScore){
    highScore = finalScore;
   




 try{ localStorage.setItem('trex_highscore', String(highScore)); }catch(e){}
  }
}

function drawSpr(base, off, sw, sh, dx, dy, dw, dh){
  ctx.drawImage(img, base.x + off*2, base.y, sw*2, sh*2, dx, dy, dw, dh);
}

function draw(){
  ctx.clearRect(0,0,W,H);
  ctx.fillStyle='#ffffff';
  ctx.fillRect(0,0,W,H);

  if(!imgLoaded){
    requestAnimationFrame(loop);
    return;
  }

  const hp = Math.floor(groundX) % 1200;
  const w1 = Math.min(W, 1200-hp);
  ctx.drawImage(img, SPR.HORIZON.x + hp*2, SPR.HORIZON.y, w1*2, 24, 0, HORIZON_Y, w1, 12);
  if(w1 < W) ctx.drawImage(img, SPR.HORIZON.x, SPR.HORIZON.y, (W-w1)*2, 24, w1, HORIZON_Y, W-w1, 12);

  for(const o of obstacles){
    if(o.type==='ptero'){
      drawSpr(SPR.PTERODACTYL, 46*o.frame, 46, 40, o.x, o.y, 46, 40);
    } else {
      const base = o.type==='cactusSmall' ? SPR.CACTUS_SMALL : SPR.CACTUS_LARGE;
      const off = (o.bw*o.size) * (0.5*(o.size-1));
      drawSpr(base, off, o.bw*o.size, o.h, o.x, o.y, o.bw*o.size, o.h);
    }
  }

  let off = 0, sw = TREX_W;
  if(gameOver){ off = 220; }
  else if(ducking){ off = runFrame ? 323 : 264; sw = TREX_DUCK_W; }
  else if(jumping){ off = 0; }
  else if(started){ off = runFrame ? 132 : 88; }
  else { off = 44; }
  drawSpr(SPR.TREX, off, sw, TREX_H, 50, trexY, sw, TREX_H);





  // Personalización de la velocidad del puntaje 
  const currentScore = Math.floor(distance/29.0);
  scoreEl.textContent = String(currentScore).padStart(5,'0');
  highEl.textContent = String(highScore).padStart(5,'0');

  // Sonido de puntos cada 100 puntos
  if (running && currentScore > 0 && currentScore % 100 === 0 && currentScore !== lastScoreSound) {
    lastScoreSound = currentScore;
    playSound('score');
  }





  ctx.fillStyle='#535353';
  ctx.textAlign='center';
  if(!started){
    ctx.font='bold 13px Arial';
    ctx.fillText('Toca para empezar', W/2, 60);
  } else if(gameOver){
    ctx.font='bold 16px Arial';
    ctx.fillText('G A M E   O V E R', W/2, 55);
    ctx.font='11px Arial';
    ctx.fillText('Toca SALTAR para reintentar', W/2, 75);
  }
}

let lastTime=0;
function loop(t){
  if(!lastTime) lastTime=t;
  const dt = Math.min(50, t-lastTime);
  lastTime = t;
  update(dt);
  draw();
  requestAnimationFrame(loop);
}
requestAnimationFrame(loop);
})();
</script>
</div>`;

const payload = { 
  response_id: crypto.randomUUID(), 
  sections: [{ 
    view_model: { 
      primitive: { 
        __typename: "GenAIaeacdsnwHtmlPrimitive", 
        payload: HTML, 
        trusted_sources: [] 
      }, 
      __typename: "GenAISingleLayoutViewModel" 
    } 
  }] 
};

await sock.relayMessage(msg.chat, { 
  messageContextInfo: { 
    deviceListMetadata: {}, 
    deviceListMetadataVersion: 2, 
    botMetadata: { 
      messageDisclaimerText: "", 
      botResponseId: crypto.randomUUID(), 
      verificationMetadata: { 
        proofs: [{ 
          version: 1, 
          useCase: 1, 
          signature: "TklYRUwuTWVzc2FnZUJ1aWxkZXJWNC43LVZlcmlmaWNhdGlvblNpZ25hdHVyZS5NZXRhZGF0YeN55YRyad2+ZA==", 
          certificateChain: ["TklYRUwuTWVzc2FnZUJ1aWxkZXJWNC43LUNlcnRpZmljYXRlQ2hhaW4uTWV0YWRhdGEOvtJr968bbpKdZreOTwkk9aPN++XPE60RfuzNLkXXc7LE8BOkN0th9/cq20ToFkW7X9c+rtYavufmuieqFhXgaMD8AGsoN9QC/HzNC9D1nydPfFYEUr9BHVy2nF5gM58Y59r2rT8p5LPARIkUp8g+5DLhyW0tdZFZ1305o4AHCayZnp5rjcU2Xi/c1Qf/djBGakmijlMs4aMzKJYD0c4Q8jdI7sNyd876K2wRD+L6KeD2QB3PtCS4P7BWAl5gh5CJ6ZBrwcaKXZqcSjEwm52MqVCgYZdapAaNYUy/QndttjLOG0wxxwuX1hIhMjPnIKZR1kwnqD5EqlHpilrnojRZvjVGN4zEKmilS8rNstt4HHs/D849W+Q6LRVWiWMs0cT2IugrX+Skxd8En7Gq52UEmuVBrSTpN+UpIu20NsVb9lsvuYh3XO441606tOEY2eKcJdZtqrOTNqbbTk0zVn1yhbOCvmfctBNDhTwaC5QMi0P9wjU5XI9SBtkdQLizc5oqpoiHeqgb8+aJHVLcbgIJ/KLZKtRWFDfzRNM02Csx4etUUapVd2NA/L0oMs/O5T9sVj9FBJ7q99GWr3PVmxJb36mHZLXC4k1gGN9swE0LtzYsUdT5tU9ri/hS3W/SM+1F1p4Kh4QIgRcG3ciIHGN44bnDh3HDCz0fDnzKYw0bclMxZPctEyJ5gEOPF6OAkjD9dEaRGq/tEPf1k9Aub+v2dEjnfrYWAm4E5Zfhs2Xh0CT0k+SzhgKd0K/46ChJ20G5+blwpIvahvTVS68+aVIX6CwXs4tcVx6FnmVsMOOkIasfaqQLZYbNBkuLoZnQAq4j8yRekrQ==", "TklYRUwuTWVzc2FnZUJ1aWxkZXJWNC43LUNlcnRpZmljYXRlQ2hhaW4uTWV0YWRhdGHsL0Ccm0ELINFZ2IaBhKaeWnVuh0o6nZLCioCn9xpSADzwIS5VCWO+1eVXT2atJOyf7FYlpB0/JA3Us+aQtekuIkHu/zBXijORZ4ClF4+sF3cSTNg6gY/+6iwLK/zs3bMg+GeJrcI65vXfs95Shxlb2Rd5GRT2/2yBmR6Zkf5QwMJuptUHWtM26WY7/xlkEKGFYDZVqOSylusiOzSALa815zC6dCiHoJNLBEKMlaZZQOk57/+OYoU5zzTaEgLhyvNFHSyAlyLQ3SGFtVHAaJZHSmmSPyJowCOB+92Gkk6SWVMsk6FbU8QJWFtlhzV/W/gZ7WzUlS/AKgN0th9/cq20ToFkW7X9c+rtYavufmuieqFhXgaMD8AGsoN9QC/HzNC9D1nydPfFYEUr9BHVy2nF5gM58Y59r2rT8p5LPARIkUp8g+5DLhyW0tdZFZ1305o4AHCayZnp5rjcU2Xi/c1Qf/djBGakmijlMs4aMzKJYD0c4Q8jdI7sNyd876K2wRD+L6KeD2QB3PtCS4P7BWAl5gh5CJ6ZBrwcaKXZqcSjEwm52MqVCgYZdapAaNYUy/QndttjLOG0wxxwuX1hIhMjPnIKZR1kwnqD5EqlHpilrnojRZvjVGN4zEKmilS8rNstt4HHs/D849W+Q6LRVWiWMs0cT2IugrX+Skxd8En7Gq52UEmuVBrSTpN+UpIu20NsVb9lsvuYh3XO441606tOEY2eKcJdZtqrOTNqbbTk0zVn1yhbOCvmfctBNDhTwaC5QMi0P9wjU5XI9SBtkdQLizc5oqpoiHeqgb8+aJHVLcbgIJ/KLZKtRWFDfzRNM02Csx4etUUapVd2NA/L0oMs/O5T9sVj9FBJ7q99GWr3PVmxJb36mHZLXC4k1gGN9swE0LtzYsUdT5tU9ri/hS3W/SM+1F1p4Kh4QIgRcG3ciIHGN44bnDh3HDCz0fDnzKYw0bclMxZPctEyJ5gEOPF6OAkjD9dEaRGq/tEPf1k9Aub+v2dEjnfrYWAm4E5Zfhs2Xh0CT0k+SzhgKd0K/46ChJ20G5+blwpIvahvTVS68+aVIX6CwXs4tcVx6FnmVsMOOkIasfaqQLZYbNBkuLoZnQAq4j8yRekrQ=="] 
        }] 
      } 
    } 
  }, 
  botForwardedMessage: { 
    message: { 
      richResponseMessage: { 
        messageType: 1, 
        submessages: [{ messageType: 2, messageText: "🦖 T-REX RUNNER" }], 
        unifiedResponse: { data: Buffer.from(JSON.stringify(payload)).toString("base64") }, 
        contextInfo: { forwardingScore: 1, isForwarded: true, forwardedAiBotMessageInfo: { botJid: "5493876664077@bot" }, forwardOrigin: 4 } 
      } 
    } 
  } 
}, {});
})()
