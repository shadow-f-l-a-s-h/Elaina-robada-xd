await (async () => {
const crypto = require('crypto');

const HTML = `<div style="width:100%;max-width:360px;margin:0 auto;background:#c0c0c0;padding:10px;box-sizing:border-box;font-family:'Courier New', monospace, sans-serif;user-select:none;border-top:3px solid #fff;border-left:3px solid #fff;border-right:3px solid #7b7b7b;border-bottom:3px solid #7b7b7b;">
  
  <!-- DIFICULTADES -->
  <div style="display:flex;justify-content:space-between;gap:4px;margin-bottom:8px;">
    <button id="dEasy" style="flex:1;padding:4px 2px;font-size:10px;font-weight:bold;background:#c0c0c0;border-top:2px solid #fff;border-left:2px solid #fff;border-right:2px solid #7b7b7b;border-bottom:2px solid #7b7b7b;cursor:pointer;">Fácil (8x8)</button>
    <button id="dMed" style="flex:1;padding:4px 2px;font-size:10px;font-weight:bold;background:#c0c0c0;border-top:2px solid #fff;border-left:2px solid #fff;border-right:2px solid #7b7b7b;border-bottom:2px solid #7b7b7b;cursor:pointer;">Medio (10x10)</button>
    <button id="dHard" style="flex:1;padding:4px 2px;font-size:10px;font-weight:bold;background:#c0c0c0;border-top:2px solid #fff;border-left:2px solid #fff;border-right:2px solid #7b7b7b;border-bottom:2px solid #7b7b7b;cursor:pointer;">Difícil (12x12)</button>
  </div>

  <!-- PANEL SUPERIOR RETRO -->
  <div style="display:flex;justify-content:space-between;align-items:center;background:#c0c0c0;padding:6px 10px;margin-bottom:8px;border-top:2px solid #7b7b7b;border-left:2px solid #7b7b7b;border-right:2px solid #fff;border-bottom:2px solid #fff;">
    <div style="background:#000;color:#ff0000;font-family:monospace;font-size:22px;font-weight:bold;padding:2px 6px;border-top:2px solid #7b7b7b;border-left:2px solid #7b7b7b;border-right:2px solid #fff;border-bottom:2px solid #fff;" id="mineDisplay">010</div>
    <button id="resetBtn" style="width:36px;height:36px;font-size:20px;background:#c0c0c0;border-top:2px solid #fff;border-left:2px solid #fff;border-right:2px solid #7b7b7b;border-bottom:2px solid #7b7b7b;cursor:pointer;display:flex;align-items:center;justify-content:center;padding:0;">🙂</button>
    <div style="background:#000;color:#ff0000;font-family:monospace;font-size:22px;font-weight:bold;padding:2px 6px;border-top:2px solid #7b7b7b;border-left:2px solid #7b7b7b;border-right:2px solid #fff;border-bottom:2px solid #fff;" id="timerDisplay">000</div>
  </div>

  <!-- SELECTOR CAVAR / BANDERAS -->
  <div style="display:flex;gap:6px;margin-bottom:8px;">
    <button id="modeDig" style="flex:1;padding:6px;font-weight:bold;font-size:12px;background:#a0a0a0;border-top:2px solid #7b7b7b;border-left:2px solid #7b7b7b;border-right:2px solid #fff;border-bottom:2px solid #fff;cursor:pointer;">⛏️ Cavar</button>
    <button id="modeFlag" style="flex:1;padding:6px;font-weight:bold;font-size:12px;background:#c0c0c0;border-top:2px solid #fff;border-left:2px solid #fff;border-right:2px solid #7b7b7b;border-bottom:2px solid #7b7b7b;cursor:pointer;">🚩 Banderas</button>
  </div>

  <!-- TABLERO -->
  <div style="background:#c0c0c0;padding:4px;border-top:3px solid #7b7b7b;border-left:3px solid #7b7b7b;border-right:3px solid #fff;border-bottom:3px solid #fff;">
    <div id="board" style="display:grid;gap:1px;width:100%;aspect-ratio:1/1;"></div>
  </div>

  <div id="statusText" style="margin-top:8px;text-align:center;font-size:11px;font-weight:bold;color:#333;height:16px;">
    Selecciona casilla para iniciar
  </div>
</div>

<script>
(function(){
  var ROWS = 8, COLS = 8, MINES = 10;
  var board = [], revealed = [], flagged = [], gameOver = false, gameStarted = false;
  var timer = 0, timerInterval = null, flagsLeft = MINES, mode = 'dig';

  var boardEl = document.getElementById('board');
  var mineDisplay = document.getElementById('mineDisplay');
  var timerDisplay = document.getElementById('timerDisplay');
  var resetBtn = document.getElementById('resetBtn');
  var statusText = document.getElementById('statusText');
  var modeDig = document.getElementById('modeDig');
  var modeFlag = document.getElementById('modeFlag');

  var btnEasy = document.getElementById('dEasy');
  var btnMed = document.getElementById('dMed');
  var btnHard = document.getElementById('dHard');

  function setDifficulty(r, c, m, activeBtn) {
    ROWS = r; COLS = c; MINES = m;
    [btnEasy, btnMed, btnHard].forEach(function(b) {
      b.style.borderTop = '2px solid #fff'; b.style.borderLeft = '2px solid #fff';
      b.style.borderRight = '2px solid #7b7b7b'; b.style.borderBottom = '2px solid #7b7b7b';
      b.style.background = '#c0c0c0';
    });
    activeBtn.style.borderTop = '2px solid #7b7b7b'; activeBtn.style.borderLeft = '2px solid #7b7b7b';
    activeBtn.style.borderRight = '2px solid #fff'; activeBtn.style.borderBottom = '2px solid #fff';
    activeBtn.style.background = '#a0a0a0';
    initGame();
  }

  btnEasy.onclick = function() { setDifficulty(8, 8, 10, btnEasy); };
  btnMed.onclick = function() { setDifficulty(10, 10, 16, btnMed); };
  btnHard.onclick = function() { setDifficulty(12, 12, 22, btnHard); };

  modeDig.onclick = function() {
    mode = 'dig';
    modeDig.style.background = '#a0a0a0';
    modeDig.style.borderTop = '2px solid #7b7b7b'; modeDig.style.borderLeft = '2px solid #7b7b7b';
    modeDig.style.borderRight = '2px solid #fff'; modeDig.style.borderBottom = '2px solid #fff';

    modeFlag.style.background = '#c0c0c0';
    modeFlag.style.borderTop = '2px solid #fff'; modeFlag.style.borderLeft = '2px solid #fff';
    modeFlag.style.borderRight = '2px solid #7b7b7b'; modeFlag.style.borderBottom = '2px solid #7b7b7b';
  };

  modeFlag.onclick = function() {
    mode = 'flag';
    modeFlag.style.background = '#a0a0a0';
    modeFlag.style.borderTop = '2px solid #7b7b7b'; modeFlag.style.borderLeft = '2px solid #7b7b7b';
    modeFlag.style.borderRight = '2px solid #fff'; modeFlag.style.borderBottom = '2px solid #fff';

    modeDig.style.background = '#c0c0c0';
    modeDig.style.borderTop = '2px solid #fff'; modeDig.style.borderLeft = '2px solid #fff';
    modeDig.style.borderRight = '2px solid #7b7b7b'; modeDig.style.borderBottom = '2px solid #7b7b7b';
  };

  function initGame() {
    board = Array(ROWS).fill(0).map(function() { return Array(COLS).fill(0); });
    revealed = Array(ROWS).fill(false).map(function() { return Array(COLS).fill(false); });
    flagged = Array(ROWS).fill(false).map(function() { return Array(COLS).fill(false); });
    gameOver = false; gameStarted = false; timer = 0; flagsLeft = MINES;
    
    mineDisplay.textContent = String(flagsLeft).padStart(3, '0');
    timerDisplay.textContent = '000';
    resetBtn.textContent = '🙂';
    statusText.textContent = 'Busca las minas sin detonar';
    statusText.style.color = '#333';
    clearInterval(timerInterval);
    renderBoard();
  }

  function placeMines(firstR, firstC) {
    var placed = 0;
    while(placed < MINES) {
      var r = Math.floor(Math.random() * ROWS);
      var c = Math.floor(Math.random() * COLS);
      if((Math.abs(r - firstR) <= 1 && Math.abs(c - firstC) <= 1) || board[r][c] === -1) continue;
      board[r][c] = -1;
      placed++;
    }
    for(var r = 0; r < ROWS; r++) {
      for(var c = 0; c < COLS; c++) {
        if(board[r][c] === -1) continue;
        var count = 0;
        for(var dr = -1; dr <= 1; dr++) {
          for(var dc = -1; dc <= 1; dc++) {
            var nr = r + dr, nc = c + dc;
            if(nr >= 0 && nr < ROWS && nc >= 0 && nc < COLS && board[nr][nc] === -1) count++;
          }
        }
        board[r][c] = count;
      }
    }
  }

  function revealCell(r, c) {
    if(gameOver || revealed[r][c] || flagged[r][c]) return;

    if(!gameStarted) {
      gameStarted = true;
      placeMines(r, c);
      timerInterval = setInterval(function() {
        timer++;
        if(timer > 999) timer = 999;
        timerDisplay.textContent = String(timer).padStart(3, '0');
      }, 1000);
    }

    if(board[r][c] === -1) {
      gameOver = true;
      clearInterval(timerInterval);
      revealAllMines();
      resetBtn.textContent = '😵';
      statusText.textContent = '💥 ¡GAME OVER!';
      statusText.style.color = '#d00';
      renderBoard();
      return;
    }

    floodReveal(r, c);
    checkWin();
    renderBoard();
  }

  function floodReveal(r, c) {
    if(r < 0 || r >= ROWS || c < 0 || c >= COLS || revealed[r][c] || flagged[r][c]) return;
    revealed[r][c] = true;
    if(board[r][c] === 0) {
      for(var dr = -1; dr <= 1; dr++) {
        for(var dc = -1; dc <= 1; dc++) {
          floodReveal(r + dr, c + dc);
        }
      }
    }
  }

  function toggleFlag(r, c) {
    if(gameOver || revealed[r][c]) return;
    if(flagged[r][c]) {
      flagged[r][c] = false;
      flagsLeft++;
    } else {
      if(flagsLeft <= 0) return;
      flagged[r][c] = true;
      flagsLeft--;
    }
    mineDisplay.textContent = String(flagsLeft).padStart(3, '0');
    renderBoard();
  }

  function revealAllMines() {
    for(var r = 0; r < ROWS; r++) {
      for(var c = 0; c < COLS; c++) {
        if(board[r][c] === -1) revealed[r][c] = true;
      }
    }
  }

  function checkWin() {
    var won = true;
    for(var r = 0; r < ROWS; r++) {
      for(var c = 0; c < COLS; c++) {
        if(board[r][c] !== -1 && !revealed[r][c]) won = false;
      }
    }
    if(won) {
      gameOver = true;
      clearInterval(timerInterval);
      resetBtn.textContent = '😎';
      statusText.textContent = '🎉 ¡VICTORIA!';
      statusText.style.color = '#080';
      renderBoard();
    }
  }

  function renderBoard() {
    boardEl.style.gridTemplateColumns = 'repeat(' + COLS + ', 1fr)';
    boardEl.innerHTML = '';
    var colors = ['', '#0000ff', '#008000', '#ff0000', '#000080', '#800000', '#008080', '#000000', '#808080'];

    for(var r = 0; r < ROWS; r++) {
      (function(r_idx){
        for(var c = 0; c < COLS; c++) {
          (function(c_idx){
            var cell = document.createElement('div');
            cell.style.cssText = 'display:flex;align-items:center;justify-content:center;font-weight:bold;font-size:13px;aspect-ratio:1/1;cursor:pointer;box-sizing:border-box;';

            if(revealed[r_idx][c_idx]) {
              cell.style.background = '#c0c0c0';
              cell.style.border = '1px solid #7b7b7b';
              if(board[r_idx][c_idx] === -1) {
                cell.textContent = '💣';
                cell.style.background = '#ff0000';
              } else if(board[r_idx][c_idx] > 0) {
                cell.textContent = board[r_idx][c_idx];
                cell.style.color = colors[board[r_idx][c_idx]] || '#000';
              }
            } else if(flagged[r_idx][c_idx]) {
              cell.style.background = '#c0c0c0';
              cell.style.borderTop = '2px solid #fff'; cell.style.borderLeft = '2px solid #fff';
              cell.style.borderRight = '2px solid #7b7b7b'; cell.style.borderBottom = '2px solid #7b7b7b';
              cell.textContent = '🚩';
            } else {
              cell.style.background = '#c0c0c0';
              cell.style.borderTop = '2px solid #fff'; cell.style.borderLeft = '2px solid #fff';
              cell.style.borderRight = '2px solid #7b7b7b'; cell.style.borderBottom = '2px solid #7b7b7b';
            }

            cell.onclick = function() {
              if(mode === 'dig') revealCell(r_idx, c_idx);
              else toggleFlag(r_idx, c_idx);
            };

            cell.oncontextmenu = function(e) {
              e.preventDefault();
              toggleFlag(r_idx, c_idx);
            };

            boardEl.appendChild(cell);
          })(c);
        }
      })(r);
    }
  }

  resetBtn.onclick = initGame;
  setDifficulty(8, 8, 10, btnEasy);
})();
<\/script>`;

const payload = { 
  response_id: crypto.randomUUID(), 
  sections: [{ 
    view_model: { 
      primitive: { 
        __typename: "GenAIaeacdsnwHtmlPrimitive", 
        payload: HTML, 
        trusted_sources: [] 
      }, 
      __typename: "GenAISingleLayoutViewModel" 
    } 
  }] 
};

await sock.relayMessage(msg.chat, {
  messageContextInfo: {
    deviceListMetadata: {},
    deviceListMetadataVersion: 2,
    botMetadata: {
      messageDisclaimerText: "",
      botResponseId: crypto.randomUUID(),
      verificationMetadata: {
        proofs: [{
          version: 1,
          useCase: 1,
          signature: "TklYRUwuTWVzc2FnZUJ1aWxkZXJWNC43LVZlcmlmaWNhdGlvblNpZ25hdHVyZS5NZXRhZGF0YeN55YRyad2+ZA==",
          certificateChain: [
            "TklYRUwuTWVzc2FnZUJ1aWxkZXJWNC43LUNlcnRpZmljYXRlQ2hhaW4uTWV0YWRhdGEOvtJr968bbpKdZreOTwkk9aPN++XPE60RfuzNLkXXc7LE8BOkN0th9/cq20ToFkW7X9c+rtYavufmuieqFhXgaMD8AGsoN9QC/HzNC9D1nydPfFYEUr9BHVy2nF5gM58Y59r2rT8p5LPARIkUp8g+5DLhyW0tdZFZ1305o4AHCayZnp5rjcU2Xi/c1Qf/djBGakmijlMs4aMzKJYD0c4Q8jdI7sNyd876K2wRD+L6KeD2QB3PtCS4P7BWAl5gh5CJ6ZBrwcaKXZqcSjEwm52MqVCgYZdapAaNYUy/QndttjLOG0wxxwuX1hIhMjPnIKZR1kwnqD5EqlHpilrnojRZvjVGN4zEKmilS8rNstt4HHs/D849W+Q6LRVWiWMs0cT2IugrX+Skxd8En7Gq52UEmuVBrSTpN+UpIu20NsVb9lsvuYh3XO441606tOEY2eKcJdZtqrOTNqbbTk0zVn1yhbOCvmfctBNDhTwaC5QMi0P9wjU5XI9SBtkdQLizc5oqpoiHeqgb8+aJHVLcbgIJ/KLZKtRWFDfzRNM02Csx4etUUapVd2NA/L0oMs/O5T9sVj9FBJ7q99GWr3PVmxJb36mHZLXC4k1gGN9swE0LtzYsUdT5tU9ri/hS3W/SM+1F1p4Kh4QIgRcG3ciIHGN44bnDh3HDCz0fDnzKYw0bclMxZPctEyJ5gEOPF6OAkjD9dEaRGq/tEPf1k9Aub+v2dEjnfrYWAm4E5Zfhs2Xh0CT0k+SzhgKd0K/46ChJ20G5+blwpIvahvTVS68+aVIX6CwXs4tcVx6FnmVsMOOkIasfaqQLZYbNBkuLoZnQAq4j8yRekrQ==",
            "TklYRUwuTWVzc2FnZUJ1aWxkZXJWNC43LUNlcnRpZmljYXRlQ2hhaW4uTWV0YWRhdGHsL0Ccm0ELINFZ2IaBhKaeWnVuh0o6nZLCioCn9xpSADzwIS5VCWO+1eVXT2atJOyf7FYlpB0/JA3Us+aQtekuIkHu/zBXijORZ4ClF4+sF3cSTNg6gY/+6iwLK/zs3bMg+GeJrcI65vXfs95Shxlb2Rd5GRT2/2yBmR6Zkf5QwMJuptUHWtM26WY7/xlkEKGFYDZVqOSylusiOzSALa815zC6dCiHoJNLBEKMlaZZQOk57/+OYoU5zzTaEgLhyvNFHSyAlyLQ3SGFtVHAaJZHSmmSPyJowCOB+92Gkk6SWVMsk6FbU8QJWFtlhzV/W/gZ7WzUlS/AKgN0th9/cq20ToFkW7X9c+rtYavufmuieqFhXgaMD8AGsoN9QC/HzNC9D1nydPfFYEUr9BHVy2nF5gM58Y59r2rT8p5LPARIkUp8g+5DLhyW0tdZFZ1305o4AHCayZnp5rjcU2Xi/c1Qf/djBGakmijlMs4aMzKJYD0c4Q8jdI7sNyd876K2wRD+L6KeD2QB3PtCS4P7BWAl5gh5CJ6ZBrwcaKXZqcSjEwm52MqVCgYZdapAaNYUy/QndttjLOG0wxxwuX1hIhMjPnIKZR1kwnqD5EqlHpilrnojRZvjVGN4zEKmilS8rNstt4HHs/D849W+Q6LRVWiWMs0cT2IugrX+Skxd8En7Gq52UEmuVBrSTpN+UpIu20NsVb9lsvuYh3XO441606tOEY2eKcJdZtqrOTNqbbTk0zVn1yhbOCvmfctBNDhTwaC5QMi0P9wjU5XI9SBtkdQLizc5oqpoiHeqgb8+aJHVLcbgIJ/KLZKtRWFDfzRNM02Csx4etUUapVd2NA/L0oMs/O5T9sVj9FBJ7q99GWr3PVmxJb36mHZLXC4k1gGN9swE0LtzYsUdT5tU9ri/hS3W/SM+1F1p4Kh4QIgRcG3ciIHGN44bnDh3HDCz0fDnzKYw0bclMxZPctEyJ5gEOPF6OAkjD9dEaRGq/tEPf1k9Aub+v2dEjnfrYWAm4E5Zfhs2Xh0CT0k+SzhgKd0K/46ChJ20G5+blwpIvahvTVS68+aVIX6CwXs4tcVx6FnmVsMOOkIasfaqQLZYbNBkuLoZnQAq4j8yRekrQ=="
          ]
        }]
      }
    }
  },
  botForwardedMessage: {
    message: {
      richResponseMessage: {
        messageType: 1,
        submessages: [{ messageType: 2, messageText: "💣 BUSCAMINAS RETRO" }],
        unifiedResponse: {
          data: Buffer.from(JSON.stringify(payload)).toString("base64")
        },
        contextInfo: {
          forwardingScore: 1,
          isForwarded: true,
          forwardedAiBotMessageInfo: { botJid: "5493876664077@bot" },
          forwardOrigin: 4
        }
      }
    }
  }
}, {});
})()