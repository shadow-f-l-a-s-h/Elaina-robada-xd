await (async () => {
const crypto = require('crypto');
const HTML = `<div style="width:100%;max-width:420px;margin:0 auto;background:#0f172a;font-family:Arial,sans-serif;padding:12px;border-radius:16px;text-align:center;box-sizing:border-box;color:white;user-select:none;touch-action:none">
<div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:10px">
  <div style="color:#38bdf8;font-weight:900;font-size:18px;letter-spacing:1px">🧩 TETRIS</div>
  <div style="background:#1e293b;padding:4px 10px;border-radius:20px;display:flex;gap:8px">
    <span style="color:#94a3b8;font-size:10px">SCORE <b id="score" style="color:white">0</b></span>
    <span style="color:#94a3b8;font-size:10px">HIGH <b id="highScore" style="color:#f59e0b">0</b></span>
    <span style="color:#94a3b8;font-size:10px">LINES <b id="lines" style="color:#38bdf8">0</b></span>
  </div>
</div>

<div style="display:flex;justify-content:center;gap:8px;align-items:flex-start;box-sizing:border-box">
  <canvas id="c" width="180" height="360" style="background:#020617;display:block;border-radius:8px;border:2px solid #334155"></canvas>
  <div style="display:flex;flex-direction:column;gap:8px">
    <div style="background:#1e293b;border:1px solid #334155;border-radius:8px;padding:6px;width:64px;box-sizing:border-box">
      <div style="font-size:8px;color:#94a3b8;margin-bottom:4px;font-weight:bold">SIGUIENTE</div>
      <canvas id="next" width="50" height="50" style="display:block;margin:0 auto"></canvas>
    </div>
    <button id="muteBtn" style="background:#1e293b;border:1px solid #334155;border-radius:8px;padding:6px;width:64px;color:white;font-size:16px;cursor:pointer;display:flex;align-items:center;justify-content:center;height:36px;box-sizing:border-box">🔊</button>
  </div>
</div>

<div style="display:grid;grid-template-columns:repeat(3, 1fr);gap:8px;max-width:260px;margin:12px auto 0">
  <button id="left" style="height:44px;border-radius:10px;background:#1e293b;color:white;border:1px solid #334155;font-size:18px">◀</button>
  <button id="down" style="height:44px;border-radius:10px;background:#0284c7;color:white;border:none;font-size:18px">▼</button>
  <button id="right" style="height:44px;border-radius:10px;background:#1e293b;color:white;border:1px solid #334155;font-size:18px">▶</button>
  <button id="rot" style="grid-column: span 3;height:44px;border-radius:10px;background:#3b82f6;color:white;border:none;font-size:18px;font-weight:bold">↻</button>
</div>

<script>
(function(){
const canvas=document.getElementById('c'), ctx=canvas.getContext('2d');
const nextCanvas=document.getElementById('next'), nextCtx=nextCanvas.getContext('2d');
const muteBtn=document.getElementById('muteBtn');
const COLS=10, ROWS=20, BLOCK=18;

const INITIAL_DROP_INTERVAL = 600; 
const SPEED_STEP_LINES = 10;      
const SPEED_DECREMENT = 80;        
const MIN_DROP_INTERVAL = 10;      

const COLORS=[null, '#00f0f0', '#0000f0', '#f0a000', '#f0f000', '#00f000', '#a000f0', '#f00000'];
const SHAPES=[
  [],
  [[1,1,1,1]],
  [[2,0,0],[2,2,2]],
  [[0,0,3],[3,3,3]],
  [[4,4],[4,4]],
  [[0,5,5],[5,5,0]],
  [[0,6,0],[6,6,6]],
  [[7,7,0],[0,7,7]]
];

let board=Array.from({length:ROWS},()=>Array(COLS).fill(0));
let score=0, lines=0, gameOver=false, gameStarted=false, dropCounter=0, dropInterval=INITIAL_DROP_INTERVAL, lastTime=0;
let highScore=0;
try {
  highScore = parseInt(localStorage.getItem('tetris_highscore') || '0', 10);
  if(isNaN(highScore)) highScore = 0;
} catch(e) {
  highScore = 0;
}
let isSoftDropping=false;
let piece=null, nextPiece=null;

let pieceDropCounts = {1:0, 2:0, 3:0, 4:0, 5:0, 6:0, 7:0};

let clearingRows = [];
let clearingTimer = 0;
const CLEAR_DURATION = 300;

let audioCtx = null;
let musicTimer = null;
let musicStep = 0;
let isMuted = false;

function initAudio(){
  if(!audioCtx){
    const AudioContext = window.AudioContext || window.webkitAudioContext;
    if(AudioContext){
      audioCtx = new AudioContext();
    }
  }
  if(audioCtx && audioCtx.state === 'suspended'){
    audioCtx.resume();
  }
}

function toggleMute(){
  isMuted = !isMuted;
  muteBtn.textContent = isMuted ? '🔇' : '🔊';
  if(isMuted){
    stopMusic();
  } else {
    if(gameStarted && !gameOver){
      playMusic();
    }
  }
}

muteBtn.onclick = (e) => {
  e.stopPropagation();
  initAudio();
  toggleMute();
};

const N = {
  E5: 659.25, B4: 493.88, C5: 523.25, D5: 587.33, A4: 440.00,
  G5: 783.99, F5: 698.46, E4: 329.63, C4: 261.63, D4: 293.66,
  GS4: 415.30, A5: 880.00, REST: 0
};

const MUSIC_MELODY = [
  {n: N.E5, d: 2}, {n: N.B4, d: 1}, {n: N.C5, d: 1}, {n: N.D5, d: 2}, {n: N.C5, d: 1}, {n: N.B4, d: 1},
  {n: N.A4, d: 2}, {n: N.A4, d: 1}, {n: N.C5, d: 1}, {n: N.E5, d: 2}, {n: N.D5, d: 1}, {n: N.C5, d: 1},
  {n: N.B4, d: 3}, {n: N.C5, d: 1}, {n: N.D5, d: 2}, {n: N.E5, d: 2},
  {n: N.C5, d: 2}, {n: N.A4, d: 2}, {n: N.A4, d: 3}, {n: N.REST, d: 1},
  {n: N.D5, d: 3}, {n: N.A5, d: 1}, {n: N.G5, d: 2}, {n: N.F5, d: 2},
  {n: N.C5, d: 3}, {n: N.E5, d: 1}, {n: N.D5, d: 2}, {n: N.C5, d: 1}, {n: N.B4, d: 1},
  {n: N.B4, d: 1}, {n: N.C5, d: 1}, {n: N.D5, d: 2}, {n: N.E5, d: 2},
  {n: N.C5, d: 2}, {n: N.A4, d: 2}, {n: N.A4, d: 3}, {n: N.REST, d: 1}
];

function playNote(freq, durationMs){
  if(isMuted || !audioCtx || freq === 0) return;
  const now = audioCtx.currentTime;
  const osc = audioCtx.createOscillator();
  const gain = audioCtx.createGain();

  osc.type = 'square';
  osc.frequency.setValueAtTime(freq, now);

  gain.gain.setValueAtTime(0.02, now);
  gain.gain.exponentialRampToValueAtTime(0.001, now + (durationMs/1000) * 0.85);

  osc.connect(gain);
  gain.connect(audioCtx.destination);

  osc.start(now);
  osc.stop(now + durationMs/1000);
}

function stopMusic(){
  if(musicTimer){
    clearTimeout(musicTimer);
    musicTimer = null;
  }
}

function playMusic(){
  stopMusic();
  if(isMuted) return;
  musicStep = 0;
  const BPM = 140;
  const unitMs = (60000 / BPM) / 2;

  function tick(){
    if(!gameStarted || gameOver || isMuted) return;
    const item = MUSIC_MELODY[musicStep];
    const durationMs = item.d * unitMs;

    if(item.n !== N.REST){
      playNote(item.n, durationMs);
    }

    musicStep = (musicStep + 1) % MUSIC_MELODY.length;
    musicTimer = setTimeout(tick, durationMs);
  }

  tick();
}

function playMoveSound(){
  if(isMuted) return;
  initAudio(); if(!audioCtx) return;
  const now = audioCtx.currentTime;
  const osc = audioCtx.createOscillator();
  const gain = audioCtx.createGain();
  osc.type = 'square';
  osc.frequency.setValueAtTime(220, now);
  osc.frequency.setValueAtTime(280, now + 0.02);
  gain.gain.setValueAtTime(0.06, now);
  gain.gain.exponentialRampToValueAtTime(0.001, now + 0.04);
  osc.connect(gain); gain.connect(audioCtx.destination);
  osc.start(now); osc.stop(now + 0.04);
}

function playRotateSound(){
  if(isMuted) return;
  initAudio(); if(!audioCtx) return;
  const now = audioCtx.currentTime;
  const osc = audioCtx.createOscillator();
  const gain = audioCtx.createGain();
  osc.type = 'square';
  osc.frequency.setValueAtTime(350, now);
  osc.frequency.exponentialRampToValueAtTime(600, now + 0.05);
  gain.gain.setValueAtTime(0.06, now);
  gain.gain.exponentialRampToValueAtTime(0.001, now + 0.05);
  osc.connect(gain); gain.connect(audioCtx.destination);
  osc.start(now); osc.stop(now + 0.05);
}

function playSoftDropSound(){
  if(isMuted) return;
  initAudio(); if(!audioCtx) return;
  const now = audioCtx.currentTime;
  const osc = audioCtx.createOscillator();
  const gain = audioCtx.createGain();
  osc.type = 'triangle';
  osc.frequency.setValueAtTime(150, now);
  gain.gain.setValueAtTime(0.04, now);
  gain.gain.exponentialRampToValueAtTime(0.001, now + 0.03);
  osc.connect(gain); gain.connect(audioCtx.destination);
  osc.start(now); osc.stop(now + 0.03);
}

function playDropSound(){
  if(isMuted) return;
  initAudio(); if(!audioCtx) return;
  const now = audioCtx.currentTime;
  const osc = audioCtx.createOscillator();
  const gain = audioCtx.createGain();
  osc.type = 'sawtooth';
  osc.frequency.setValueAtTime(160, now);
  osc.frequency.exponentialRampToValueAtTime(60, now + 0.08);
  gain.gain.setValueAtTime(0.1, now);
  gain.gain.exponentialRampToValueAtTime(0.001, now + 0.08);
  osc.connect(gain); gain.connect(audioCtx.destination);
  osc.start(now); osc.stop(now + 0.08);
}

function playClearSound(count){
  if(isMuted) return;
  initAudio(); if(!audioCtx) return;
  const now = audioCtx.currentTime;
  const notes = count === 4 ? [523, 659, 783, 1046, 1318] : [440, 554, 659, 880];

  notes.forEach((freq, i) => {
    const osc = audioCtx.createOscillator();
    const gain = audioCtx.createGain();
    const startTime = now + (i * 0.05);
    osc.type = 'square';
    osc.frequency.setValueAtTime(freq, startTime);
    gain.gain.setValueAtTime(0.08, startTime);
    gain.gain.exponentialRampToValueAtTime(0.001, startTime + 0.08);
    osc.connect(gain); gain.connect(audioCtx.destination);
    osc.start(startTime); osc.stop(startTime + 0.08);
  });
}

function playGameOverSound(){
  stopMusic();
  if(isMuted) return;
  initAudio(); if(!audioCtx) return;
  const now = audioCtx.currentTime;
  const notes = [300, 260, 220, 180, 140];
  notes.forEach((freq, i) => {
    const osc = audioCtx.createOscillator();
    const gain = audioCtx.createGain();
    const startTime = now + (i * 0.12);
    osc.type = 'sawtooth';
    osc.frequency.setValueAtTime(freq, startTime);
    gain.gain.setValueAtTime(0.09, startTime);
    gain.gain.exponentialRampToValueAtTime(0.001, startTime + 0.14);
    osc.connect(gain); gain.connect(audioCtx.destination);
    osc.start(startTime); osc.stop(startTime + 0.14);
  });
}

// Generador de piezas con la regla de las 12 caídas (Tetris clásico)
function getRandomPieceType() {
  // Verificar si alguna pieza superó las 12 caídas sin salir
  for (let type = 1; type <= 7; type++) {
    if (pieceDropCounts[type] >= 12) {
      pieceDropCounts[type] = 0; // Se resetea
      // Incrementamos el contador de todas las demás piezas
      for (let t = 1; t <= 7; t++) {
        if (t !== type) pieceDropCounts[t]++;
      }
      return type;
    }
  }

  // Si ninguna superó las 12, tirada aleatoria normal
  const chosenType = Math.floor(Math.random() * 7) + 1;

  // Actualizar contadores: la elegida se pone en 0, las demás suman 1
  for (let t = 1; t <= 7; t++) {
    if (t === chosenType) {
      pieceDropCounts[t] = 0;
    } else {
      pieceDropCounts[t]++;
    }
  }

  return chosenType;
}

function createPiece(type){
  return { matrix: SHAPES[type], color: type, x: Math.floor(COLS/2)-1, y: 0 };
}

function startGame(){
  initAudio();
  if(gameStarted && !gameOver) return;
  gameStarted=true;
  reset();
  playMusic();
  update();
}

function reset(){
  board=Array.from({length:ROWS},()=>Array(COLS).fill(0));
  score=0; lines=0; gameOver=false; dropInterval=INITIAL_DROP_INTERVAL; isSoftDropping=false;
  pieceDropCounts = {1:0, 2:0, 3:0, 4:0, 5:0, 6:0, 7:0};
  clearingRows = [];
  clearingTimer = 0;
  updateScore();
  nextPiece=createPiece(getRandomPieceType());
  spawnPiece();
}

function spawnPiece(){
  piece=nextPiece;
  nextPiece=createPiece(getRandomPieceType());
  drawNext();
  if(collide(board, piece)){
    gameOver=true;
    playGameOverSound();
  }
}

function collide(board, piece){
  const m=piece.matrix;
  for(let y=0; y<m.length; y++){
    for(let x=0; x<m[y].length; x++){
      if(m[y][x] !== 0){
        let newX=piece.x+x, newY=piece.y+y;
        if(newX<0 || newX>=COLS || newY>=ROWS) return true;
        if(newY>=0 && board[newY][newX] !== 0) return true;
      }
    }
  }
  return false;
}

function merge(board, piece){
  piece.matrix.forEach((row, y)=>{
    row.forEach((val, x)=>{
      if(val !== 0 && piece.y+y >= 0){
        board[piece.y+y][piece.x+x] = piece.color;
      }
    });
  });
}

function rotate(matrix){
  return matrix[0].map((_, i) => matrix.map(row => row[i]).reverse());
}

function playerRotate(){
  if(!gameStarted || gameOver || clearingRows.length > 0) return;
  const pos=piece.x;
  let offset=1;
  const rotated=rotate(piece.matrix);
  const oldMatrix=piece.matrix;
  piece.matrix=rotated;
  while(collide(board, piece)){
    piece.x += offset;
    offset = -(offset + (offset > 0 ? 1 : -1));
    if(offset > piece.matrix[0].length){
      piece.matrix = oldMatrix;
      piece.x = pos;
      return;
    }
  }
  playRotateSound();
}

function playerMove(dir){
  if(!gameStarted || gameOver || clearingRows.length > 0) return;
  piece.x += dir;
  if(collide(board, piece)){
    piece.x -= dir;
  } else {
    playMoveSound();
  }
}

function playerDrop(){
  if(clearingRows.length > 0) return;
  piece.y++;
  if(collide(board, piece)){
    piece.y--;
    merge(board, piece);
    if(!checkAndStartClear()){
      playDropSound();
      spawnPiece();
    }
  } else {
    if(isSoftDropping) playSoftDropSound();
  }
  dropCounter=0;
}

function checkAndStartClear(){
  clearingRows = [];
  for(let y=ROWS-1; y>=0; y--){
    if(board[y].every(val => val !== 0)){
      clearingRows.push(y);
    }
  }
  if(clearingRows.length > 0){
    clearingTimer = CLEAR_DURATION;
    playClearSound(clearingRows.length);
    return true;
  }
  return false;
}

function executeClear(){
  let rowCount = clearingRows.length;
  clearingRows.sort((a, b) => a - b);
  clearingRows.forEach(y => {
    board.splice(y, 1);
    board.unshift(Array(COLS).fill(0));
  });

  lines += rowCount;
  score += [0, 40, 100, 300, 1200][rowCount] || 0;
  if(score > highScore){
    highScore = score;
    try {
      localStorage.setItem('tetris_highscore', highScore);
    } catch(e){}
  }

  const speedLevel = Math.floor(lines / SPEED_STEP_LINES); 
  dropInterval = Math.max(MIN_DROP_INTERVAL, INITIAL_DROP_INTERVAL - (speedLevel * SPEED_DECREMENT)); 

  updateScore();
  clearingRows = [];
  spawnPiece();
}

function updateScore(){
  document.getElementById('score').textContent=score;
  document.getElementById('highScore').textContent=highScore;
  document.getElementById('lines').textContent=lines;
}

function drawBlock(ctx, x, y, colorIndex, size=BLOCK){
  ctx.fillStyle=COLORS[colorIndex];
  ctx.fillRect(x*size+1, y*size+1, size-2, size-2);
  ctx.fillStyle='rgba(255,255,255,0.2)';
  ctx.fillRect(x*size+1, y*size+1, size-2, 2);
}

function draw(){
  ctx.fillStyle='#020617';
  ctx.fillRect(0,0,canvas.width,canvas.height);

  board.forEach((row, y)=>{
    if(clearingRows.includes(y)){
      const flash = Math.floor(clearingTimer / 50) % 2 === 0;
      if(flash){
        ctx.fillStyle='#ffffff';
        for(let x=0; x<COLS; x++){
          ctx.fillRect(x*BLOCK+1, y*BLOCK+1, BLOCK-2, BLOCK-2);
        }
      }
    } else {
      row.forEach((val, x)=>{
        if(val>0) drawBlock(ctx, x, y, val);
      });
    }
  });

  if(piece && gameStarted && clearingRows.length === 0){
    piece.matrix.forEach((row, y)=>{
      row.forEach((val, x)=>{
        if(val>0 && piece.y+y>=0) drawBlock(ctx, piece.x+x, piece.y+y, piece.color);
      });
    });
  }

  if(!gameStarted){
    ctx.fillStyle='rgba(0,0,0,0.75)';
    ctx.fillRect(0,0,canvas.width,canvas.height);
    ctx.fillStyle='#38bdf8';
    ctx.font='bold 18px Arial';
    ctx.textAlign='center';
    ctx.fillText('¡BIENVENIDO!', 90, 160);
    ctx.fillStyle='white';
    ctx.font='12px Arial';
    ctx.fillText('Toca para iniciar', 90, 190);
  } else if(gameOver){
    ctx.fillStyle='rgba(0,0,0,0.85)';
    ctx.fillRect(0,0,canvas.width,canvas.height);
    ctx.fillStyle='#ef4444';
    ctx.font='bold 18px Arial';
    ctx.textAlign='center';
    ctx.fillText('GAME OVER', 90, 160);
    ctx.fillStyle='white';
    ctx.font='11px Arial';
    ctx.fillText('Toca para reiniciar', 90, 190);
  }
}

function drawNext(){
  nextCtx.fillStyle='#1e293b';
  nextCtx.fillRect(0,0,50,50);
  if(!nextPiece || !gameStarted) return;
  const m=nextPiece.matrix;
  const size=10;
  const offsetX=(50 - m[0].length*size)/2;
  const offsetY=(50 - m.length*size)/2;
  m.forEach((row, y)=>{
    row.forEach((val, x)=>{
      if(val>0){
        nextCtx.fillStyle=COLORS[nextPiece.color];
        nextCtx.fillRect(offsetX + x*size + 1, offsetY + y*size + 1, size-2, size-2);
      }
    });
  });
}

function update(time=0){
  const deltaTime = time - lastTime;
  lastTime = time;

  if(gameStarted && !gameOver){
    if(clearingRows.length > 0){
      clearingTimer -= deltaTime;
      if(clearingTimer <= 0){
        executeClear();
      }
    } else {
      dropCounter += deltaTime;
      const currentInterval = isSoftDropping ? 15 : dropInterval;
      if(dropCounter > currentInterval){
        playerDrop();
      }
    }
    draw();
    requestAnimationFrame(update);
  } else {
    draw();
  }
}

function bindHoldBtn(id, startFn, endFn){
  const el = document.getElementById(id);
  let timer = null;
  let interval = null;

  const start = (e) => {
    if(e) e.preventDefault();
    initAudio();
    if(!gameStarted || gameOver){ startGame(); return; }
    startFn();
    timer = setTimeout(() => {
      interval = setInterval(startFn, 60);
    }, 180);
  };

  const stop = (e) => {
    if(e) e.preventDefault();
    clearTimeout(timer);
    clearInterval(interval);
    if(endFn) endFn();
  };

  el.addEventListener('mousedown', start);
  el.addEventListener('mouseup', stop);
  el.addEventListener('mouseleave', stop);
  el.addEventListener('touchstart', start);
  el.addEventListener('touchend', stop);
  el.addEventListener('touchcancel', stop);
}

bindHoldBtn('left', () => playerMove(-1));
bindHoldBtn('right', () => playerMove(1));
bindHoldBtn('down', () => { isSoftDropping = true; }, () => { isSoftDropping = false; });

document.getElementById('rot').onclick = () => { initAudio(); if(!gameStarted || gameOver){ startGame(); } else playerRotate(); };

canvas.onclick = () => { initAudio(); if(!gameStarted || gameOver){ startGame(); } };

document.addEventListener('keydown', e => {
  initAudio();
  if(!gameStarted || gameOver){ if(e.key==='Enter' || e.key===' '){ startGame(); } return; }
  if(e.repeat) return;
  if(e.key==='ArrowLeft') playerMove(-1);
  else if(e.key==='ArrowRight') playerMove(1);
  else if(e.key==='ArrowDown' || e.key===' ') isSoftDropping = true;
  else if(e.key==='ArrowUp') playerRotate();
});

document.addEventListener('keyup', e => {
  if(e.key==='ArrowDown' || e.key===' ') isSoftDropping = false;
});

updateScore();
draw();
})();
</script>
</div>`;

const payload = { 
  response_id: crypto.randomUUID(), 
  sections: [{ 
    view_model: { 
      primitive: { 
        __typename: "GenAIaeacdsnwHtmlPrimitive", 
        payload: HTML, 
        trusted_sources: [] 
      }, 
      __typename: "GenAISingleLayoutViewModel" 
    } 
  }] 
};

await sock.relayMessage(msg.chat, { 
  messageContextInfo: { 
    deviceListMetadata: {}, 
    deviceListMetadataVersion: 2, 
    botMetadata: { 
      messageDisclaimerText: "", 
      botResponseId: crypto.randomUUID(), 
      verificationMetadata: { 
        proofs: [{ 
          version: 1, 
          useCase: 1, 
          signature: "TklYRUwuTWVzc2FnZUJ1aWxkZXJWNC43LVZlcmlmaWNhdGlvblNpZ25hdHVyZS5NZXRhZGF0YeN55YRyad2+ZA==", 
          certificateChain: ["TklYRUwuTWVzc2FnZUJ1aWxkZXJWNC43LUNlcnRpZmljYXRlQ2hhaW4uTWV0YWRhdGEOvtJr968bbpKdZreOTwkk9aPN++XPE60RfuzNLkXXc7LE8BOkN0th9/cq20ToFkW7X9c+rtYavufmuieqFhXgaMD8AGsoN9QC/HzNC9D1nydPfFYEUr9BHVy2nF5gM58Y59r2rT8p5LPARIkUp8g+5DLhyW0tdZFZ1305o4AHCayZnp5rjcU2Xi/c1Qf/djBGakmijlMs4aMzKJYD0c4Q8jdI7sNyd876K2wRD+L6KeD2QB3PtCS4P7BWAl5gh5CJ6ZBrwcaKXZqcSjEwm52MqVCgYZdapAaNYUy/QndttjLOG0wxxwuX1hIhMjPnIKZR1kwnqD5EqlHpilrnojRZvjVGN4zEKmilS8rNstt4HHs/D849W+Q6LRVWiWMs0cT2IugrX+Skxd8En7Gq52UEmuVBrSTpN+UpIu20NsVb9lsvuYh3XO441606tOEY2eKcJdZtqrOTNqbbTk0zVn1yhbOCvmfctBNDhTwaC5QMi0P9wjU5XI9SBtkdQLizc5oqpoiHeqgb8+aJHVLcbgIJ/KLZKtRWFDfzRNM02Csx4etUUapVd2NA/L0oMs/O5T9sVj9FBJ7q99GWr3PVmxJb36mHZLXC4k1gGN9swE0LtzYsUdT5tU9ri/hS3W/SM+1F1p4Kh4QIgRcG3ciIHGN44bnDh3HDCz0fDnzKYw0bclMxZPctEyJ5gEOPF6OAkjD9dEaRGq/tEPf1k9Aub+v2dEjnfrYWAm4E5Zfhs2Xh0CT0k+SzhgKd0K/46ChJ20G5+blwpIvahvTVS68+aVIX6CwXs4tcVx6FnmVsMOOkIasfaqQLZYbNBkuLoZnQAq4j8yRekrQ==", "TklYRUwuTWVzc2FnZUJ1aWxkZXJWNC43LUNlcnRpZmljYXRlQ2hhaW4uTWV0YWRhdGHsL0Ccm0ELINFZ2IaBhKaeWnVuh0o6nZLCioCn9xpSADzwIS5VCWO+1eVXT2atJOyf7FYlpB0/JA3Us+aQtekuIkHu/zBXijORZ4ClF4+sF3cSTNg6gY/+6iwLK/zs3bMg+GeJrcI65vXfs95Shxlb2Rd5GRT2/2yBmR6Zkf5QwMJuptUHWtM26WY7/xlkEKGFYDZVqOSylusiOzSALa815zC6dCiHoJNLBEKMlaZZQOk57/+OYoU5zzTaEgLhyvNFHSyAlyLQ3SGFtVHAaJZHSmmSPyJowCOB+92Gkk6SWVMsk6FbU8QJWFtlhzV/W/gZ7WzUlS/AKgN0th9/cq20ToFkW7X9c+rtYavufmuieqFhXgaMD8AGsoN9QC/HzNC9D1nydPfFYEUr9BHVy2nF5gM58Y59r2rT8p5LPARIkUp8g+5DLhyW0tdZFZ1305o4AHCayZnp5rjcU2Xi/c1Qf/djBGakmijlMs4aMzKJYD0c4Q8jdI7sNyd876K2wRD+L6KeD2QB3PtCS4P7BWAl5gh5CJ6ZBrwcaKXZqcSjEwm52MqVCgYZdapAaNYUy/QndttjLOG0wxxwuX1hIhMjPnIKZR1kwnqD5EqlHpilrnojRZvjVGN4zEKmilS8rNstt4HHs/D849W+Q6LRVWiWMs0cT2IugrX+Skxd8En7Gq52UEmuVBrSTpN+UpIu20NsVb9lsvuYh3XO441606tOEY2eKcJdZtqrOTNqbbTk0zVn1yhbOCvmfctBNDhTwaC5QMi0P9wjU5XI9SBtkdQLizc5oqpoiHeqgb8+aJHVLcbgIJ/KLZKtRWFDfzRNM02Csx4etUUapVd2NA/L0oMs/O5T9sVj9FBJ7q99GWr3PVmxJb36mHZLXC4k1gGN9swE0LtzYsUdT5tU9ri/hS3W/SM+1F1p4Kh4QIgRcG3ciIHGN44bnDh3HDCz0fDnzKYw0bclMxZPctEyJ5gEOPF6OAkjD9dEaRGq/tEPf1k9Aub+v2dEjnfrYWAm4E5Zfhs2Xh0CT0k+SzhgKd0K/46ChJ20G5+blwpIvahvTVS68+aVIX6CwXs4tcVx6FnmVsMOOkIasfaqQLZYbNBkuLoZnQAq4j8yRekrQ=="] 
        }] 
      } 
    } 
  }, 
  botForwardedMessage: { 
    message: { 
      richResponseMessage: { 
        messageType: 1, 
        submessages: [{ messageType: 2, messageText: "🧩 TETRIS" }], 
        unifiedResponse: { data: Buffer.from(JSON.stringify(payload)).toString("base64") }, 
        contextInfo: { forwardingScore: 1, isForwarded: true, forwardedAiBotMessageInfo: { botJid: "5493876664077@bot" }, forwardOrigin: 4 } 
      } 
    } 
  } 
}, {});
})()
