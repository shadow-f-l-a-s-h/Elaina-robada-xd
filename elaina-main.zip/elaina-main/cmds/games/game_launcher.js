import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import syntaxerror from 'syntax-error';
import { format } from 'util';
import { createRequire } from 'module';

const require = createRequire(import.meta.url);
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const GAMES_DIR = path.resolve(__dirname, './cartuchos');

export default {
  command: ['game', 'juego', 'jugar'],
  category: 'owner',
  description: 'Launcher dinámico de cartuchos.',
  isOwner: true,
  run: async ({ msg, sock, args, command, usedPrefix, text }) => {
    let rawCode = '';
    try {
      if (!fs.existsSync(GAMES_DIR)) {
        fs.mkdirSync(GAMES_DIR, { recursive: true });
      }

      const files = fs.readdirSync(GAMES_DIR).filter(f => f.endsWith('.js'));
      const availableGames = files.map(f => path.basename(f, '.js').toLowerCase());

      const targetGame = args[0]?.toLowerCase()?.trim();

      if (!targetGame || !availableGames.includes(targetGame)) {
        const currentPrefix = usedPrefix || '#';
        const currentCommand = command || 'game';
        
        const listText = availableGames.length > 0 
          ? `🎮 *Cartuchos disponibles:*\n\n` + availableGames.map(g => `• \`${g}\``).join('\n') + `\n\n> Usa *${currentPrefix}${currentCommand} <cartucho>* para jugar.`
          : `⚠️ No hay juegos en \`cmds/games/cartuchos/\`.`;

        return sock.sendMessage(msg.chat || msg.key?.remoteJid, { text: listText }, { quoted: msg });
      }

      const gameFilePath = path.join(GAMES_DIR, `${targetGame}.js`);
      rawCode = fs.readFileSync(gameFilePath, 'utf8');

      await msg.react?.('🕒');

      let i = 15;
      let f = { exports: {} };

      const exec = new (async () => {}).constructor(
        'print', 'msg', 'sock', 'require', 'Array', 'process', 'args', 'usedPrefix', 'command', 'module', 'exports', 'argument', 
        rawCode
      );      

      await exec.call(
        sock, 
        (...a) => {
          if (--i < 1) return;
          return sock.reply ? sock.reply(msg.chat, format(...a), msg) : sock.sendMessage(msg.chat, { text: format(...a) }, { quoted: msg });
        }, 
        msg, 
        sock, 
        require, 
        Array, 
        process, 
        args, 
        usedPrefix,
        command,
        f, 
        f.exports, 
        [sock]
      );      

      await msg.react?.('');
    } catch (e) {
      console.error(`[Error ejecutando cartucho "${args[0]}"]`, e);

      const syntaxErr = rawCode
        ? syntaxerror(rawCode, `${args[0]}.js`, {
            allowReturnOutsideFunction: true,
            allowAwaitOutsideFunction: true,
            sourceType: 'module'
          })
        : null;

      const detalle = String(syntaxErr || e?.stack || e).slice(0, 3500);

      await msg.react?.('✖️');
      await sock.sendMessage(
        msg.chat || msg.key?.remoteJid,
        { text: `❌ *Error en el cartucho "${args[0]}":*\n\n\`\`\`${detalle}\`\`\`` },
        { quoted: msg }
      );
    }
  }
};
