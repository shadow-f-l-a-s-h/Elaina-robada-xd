import db from "#db";
import ws from 'ws';
import moment from 'moment';
import chalk from 'chalk';
import fs from 'fs';
import path from 'path';
import gradient from 'gradient-string';
import { getCachedMeta, setCachedMeta } from '#serialize';

export default async (sock, msg) => {

  if (msg.fromMe && !msg.key.participant && msg.isBot) return;  
  const sender = msg.sender || '';
  let body = msg.body || '';

  const from = msg.key.remoteJid;
  const botJid = sock.user?.id ? (sock.user.id.split(':')[0] + '@s.whatsapp.net') : (sock.user?.lid || '');

  const chatData = (await db.getChat(msg.chat)) || {};
  const settings = (await db.getSettings(botJid)) || {};  

  const cleanNumber = (jid) => String(jid || '').split('@')[0].split(':')[0].replace(/\D/g, '');
  const senderNum = cleanNumber(sender);
  
  const ownersList = (global.owner || []).map(o => Array.isArray(o) ? cleanNumber(o[0]) : cleanNumber(o)).filter(Boolean);
  const modsList = (global.mods || []).map(m => Array.isArray(m) ? cleanNumber(m[0]) : cleanNumber(m)).filter(Boolean);

  const isOwner = ownersList.includes(senderNum) || sender === botJid;
  const isROwner = isOwner || (settings.owner && cleanNumber(settings.owner) === senderNum);
  const isSocket = msg.key.fromMe || sender === botJid;

  if (chatData?.isBanned && !isOwner && !isSocket) return;

  let groupMetadata = null;
  let groupName = '';
  if (msg.isGroup) {
    groupMetadata = getCachedMeta(msg.chat);
    if (!groupMetadata) {
      groupMetadata = await sock.groupMetadata(msg.chat).catch(() => null);
      if (groupMetadata) setCachedMeta(msg.chat, groupMetadata);
    }
    groupName = groupMetadata?.subject || '';
  }
  const participants = groupMetadata?.participants || [];
  
  const adminSet = new Set(
    participants
      .filter(p => p.admin === 'admin' || p.admin === 'superadmin')
      .flatMap(p => [cleanNumber(p.id), cleanNumber(p.lid), cleanNumber(p.phoneNumber)].filter(Boolean))
  );

  const senderBase = cleanNumber(sender);
  const botBase = cleanNumber(botJid);
  const isBotAdmins = msg.isGroup ? adminSet.has(botBase) : false;
  const isAdmins = msg.isGroup ? adminSet.has(senderBase) : false;

  Promise.allSettled((global.cmdsExecute ?? []).filter(p => p.type === 'all').map(p => p.fn({ msg, sock, groupMetadata, participants, isAdmins, isBotAdmins, isOwner, __dirname: p.dirname }).catch(e => console.error(chalk.gray(`[ ✿ ] Error all-plugin ${p.key}: ${e.message}`)))));

  const tf = await db.getChatUser(msg.chat, msg.sender);
  const to = new Date().toLocaleDateString('es-CO', { timeZone: 'America/Bogota', year: 'numeric', month: '2-digit', day: '2-digit' }).split('/').reverse().join('-'); 

  if (!tf) {
    await db.updateChatUser(msg.chat, msg.sender, { stats: { [to]: { msgs: 0, cmds: 0 } } });
  } else {
    if (!tf.stats) tf.stats = {};
    if (!tf.stats[to]) tf.stats[to] = { msgs: 0, cmds: 0 };
    tf.stats[to].msgs++;
    await db.updateChatUser(msg.chat, msg.sender, 'stats', tf.stats);
  }

  const rawBotname = settings.namebot2 || 'Stellar';
  const tipo = settings.type || 'Sub';
  const cleanBotname = rawBotname.replace(/[^a-zA-Z0-9\s]/g, '');
  const namebot = cleanBotname || 'Stellar';
  const shortForms = [namebot.charAt(0), namebot.split(" ")[0], tipo.split(" ")[0], namebot.split(" ")[0].slice(0, 2), namebot.split(" ")[0].slice(0, 3)];
  const prefixes = shortForms.map(name => `${name}`);
  prefixes.unshift(namebot);
  let prefix;
  if (Array.isArray(settings.prefijo) || typeof settings.prefijo === 'string') {
    const prefixArray = Array.isArray(settings.prefijo) ? settings.prefijo : [settings.prefijo];
    prefix = new RegExp('^(' + prefixes.join('|') + ')?(' + prefixArray.map(p => p.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')).join('|') + ')', 'i');
  } else if (settings.prefijo === 1) {
    prefix = new RegExp('^', 'i');
  } else {
    prefix = new RegExp('^(' + prefixes.join('|') + ')?', 'i');
  }
  const strRegex = (str) => str.replace(/[|\\{}()[\]^$+*?.]/g, '\\$&');
  let customCmd = null;
  let pluginPrefix = prefix;
  for (const [cmdName, data] of global.comandos) {
    if (!data.customPrefix) continue;
    const cp = data.customPrefix;
    const ms = cp instanceof RegExp ? [[cp.exec(body), cp]] : Array.isArray(cp) ? cp.map(p => { let r = p instanceof RegExp ? p : new RegExp(strRegex(p)); return [r.exec(body), r]; }) : typeof cp === 'string' ? [[new RegExp(strRegex(cp)).exec(body), new RegExp(strRegex(cp))]] : [[null, null]];
    if (ms.find(p => p[0])) { customCmd = cmdName; pluginPrefix = cp; break; }
  }
  let matchs = pluginPrefix instanceof RegExp ? [[pluginPrefix.exec(body), pluginPrefix]] : Array.isArray(pluginPrefix) ? pluginPrefix.map(p => {
    let regex = p instanceof RegExp ? p : new RegExp(strRegex(p));
    return [regex.exec(body), regex];
  }) : typeof pluginPrefix === 'string' ? [[new RegExp(strRegex(pluginPrefix)).exec(body), new RegExp(strRegex(pluginPrefix))]] : [[null, null]];
  let match = matchs.find(p => p[0]) || null;

  for (const p of (global.cmdsExecute ?? [])) {
    if (p.type !== 'before') continue;
    try {
      if (await p.fn({ msg, sock, match, groupMetadata, participants, isAdmins, isBotAdmins, isOwner, __dirname: p.dirname })) continue;
    } catch (e) {
      console.error(chalk.gray(`[ ✿ ] Error before-plugin ${p.key}: ${e.message}`));
    }
  }

  if (!match) return;
  let usedPrefix = (match[0] || [])[0] || '';
  let args = body.slice(usedPrefix.length).trim().split(" ");
  let command = customCmd ?? (args.shift() || '').toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '');
  let text = args.join(' ');
  if (!command) return;

  const pushname = msg.pushName || 'Sin nombre';

  const consolePrimary = chatData.primaryBot;

  if (msg.message || !consolePrimary || consolePrimary === botJid) {
    console.log(`
𝄢 · • —– ٠ ✤ ٠ —– • · · • —– ٠ ✤ ٠ —– • ·✧༄
❚ ▸ ${chalk.cyan('𝐁𝐎𝐓 ❱❱')} ${chalk.bgMagenta(chalk.white.italic(sock.user.name))}
❚ ▸ ${chalk.cyan('𝐇𝐎𝐑𝐀𝐑𝐈𝐎 ❱❱')} ${chalk.black.bgWhite(moment().format('DD/MM/YY HH:mm:ss'))}
❚ ${chalk.magentaBright('°o.OO.o°°o.OO.o°°o.OO.o°')}
❚ ▸ ${chalk.green('𝐔𝐒𝐔𝐀𝐑𝐈𝐎 ❱❱')} ${chalk.white(pushname)} / ${chalk.bgMagentaBright.bold(msg.isGroup ? 'Grupo' : 'Chat Private')}
❚ ▸ ${chalk.green('𝐂𝐎𝐌𝐀𝐍𝐃𝐎 ❱❱')} ${chalk.magentaBright(command ? command : 'No Command')}
❚ ${chalk.magentaBright('°o.OO.o°°o.OO.o°°o.OO.o°')}
❚ ▸ ${chalk.redBright('𝐓𝐈𝐏𝐎 ❱❱')} ${chalk.greenBright.bold('[Bot Log]')}
𝄢 · • —– ٠ ✤ ٠ —– • · · • —– ٠ ✤ ٠ —– • ·✧༄`.trim());
  }

  const hasPrefix = (settings.prefijo === 1 || settings.prefijo === true) ? true : (Array.isArray(settings.prefijo) ? settings.prefijo : typeof settings.prefijo === 'string' ? [settings.prefijo] : []).some(p => body?.startsWith(p));
  const botprimaryId = chatData?.primaryBot;
  if (botprimaryId && botprimaryId !== botJid) {
    if (hasPrefix) {
      const groupJids = participants.map(p => p.id);
      const sessionDirs = ['./Sessions/Subs'];
      function getAllSessionBots() {
        const bots = [];
        for (const dir of sessionDirs) {
          try {
            for (const sub of fs.readdirSync(path.resolve(dir))) {
              if (fs.existsSync(path.resolve(dir, sub, 'creds.json')))
                bots.push(sub + '@s.whatsapp.net');
            }
          } catch {}
        }
        try {
          if (fs.existsSync(path.resolve('./Sessions/Owner/creds.json'))) {
            const ownerId = global.sock?.user?.id?.split(':')[0] + '@s.whatsapp.net';
            if (ownerId) bots.push(ownerId);
          }
        } catch {}
        return bots;
      }
      const sessionBots = getAllSessionBots();
      const primaryInGroup = groupJids.includes(botprimaryId);
      const isPrimarySelf = botprimaryId === botJid;
      const primaryInSessions = sessionBots.includes(botprimaryId);
      if (!primaryInSessions || !primaryInGroup) return;
      if ((primaryInSessions && primaryInGroup) || isPrimarySelf) return;
    }
  }

  if (settings.self) {
    const ownerSettingsNum = cleanNumber(settings.owner);
    if (
      senderNum !== ownerSettingsNum &&
      !isOwner &&
      !modsList.includes(senderNum)
    ) return;
  }

  if (msg.chat && !msg.chat.endsWith('g.us')) {
    const allowedInPrivateForUsers = ['report', 'reporte', 'sug', 'suggest', 'invite', 'invitar', 'setusername', 'setpfp', 'setimage', 'setstatus', 'reload', 'setname', 'setbotname', 'setmenubanner', 'setbanner', 'setbotcurrency', 'code', 'qr', 'setbotowner', 'setlink', 'setbotlink', 'setbotprefix'];
    const ownerSettingsNum = cleanNumber(settings.owner);
    if (
      senderNum !== ownerSettingsNum &&
      !isOwner &&
      !allowedInPrivateForUsers.includes(command)
    ) return;
  }

  if (chatData.adminonly && !isAdmins) return;

  if (msg.fromMe && (msg.id.startsWith("3EB0") || (msg.id.startsWith("BAE5") && msg.id.length === 16) || (msg.id.startsWith("B24E") && msg.id.length === 20))) return;

  const user = await db.getChatUser(msg.chat, msg.sender);

  const today = new Date().toLocaleDateString('es-CO', { 
    timeZone: 'America/Bogota',
    year: 'numeric',
    month: '2-digit',
    day: '2-digit'
  }).split('/').reverse().join('-'); 

  if (!user) {
    await db.updateChatUser(msg.chat, msg.sender, { stats: { [today]: { msgs: 0, cmds: 0 } } });
  } else {
    if (!user.stats) user.stats = {};
    if (!user.stats[today]) user.stats[today] = { msgs: 0, cmds: 0 };
  }

  const cmdData = global.comandos.get(command);

  if (!cmdData || user.muted === 1 || user.muted === true) {
    if (settings.prefijo === 1 || settings.prefijo === true || user.muted === 1 || user.muted === true) return;
    await sock.readMessages([msg.key]);
    return msg.reply(`ꕤ El comando *${command}* no existe.\n✎ Usa *${usedPrefix}help* para ver la lista de comandos disponibles.`);
  }

  if (cmdData.isOwner && !isOwner) {
    return msg.reply(`ꕤ El comando *${command}* no existe.\n✎ Usa *${usedPrefix}help* para ver la lista de comandos disponibles.`);
  }

  if (cmdData.isAdmin && !isAdmins) return sock.reply(msg.chat, mess.admin, msg);
  if (cmdData.botAdmin && !isBotAdmins) return sock.reply(msg.chat, mess.botAdmin, msg);

  try {
    await sock.readMessages([msg.key]);
    const user2 = await db.getUser(msg.sender);

    if (!user2) {
      await db.updateUser(msg.sender, { usedcommands: 1, exp: Math.floor(Math.random() * 100), name: msg.pushName });
    } else {
      user2.usedcommands = (user2.usedcommands || 0) + 1;
      user2.exp = (user2.exp || 0) + Math.floor(Math.random() * 100);
      user2.name = msg.pushName;
      await db.updateUser(msg.sender, 'exp', user2.exp);
      await db.updateUser(msg.sender, 'name', user2.name);
      await db.updateUser(msg.sender, 'usedcommands', user2.usedcommands);
    }

    settings.commandsejecut = (settings.commandsejecut || 0) + 1;
    await db.updateSettings(botJid, 'commandsejecut', settings.commandsejecut);

    const userStats = await db.getChatUser(msg.chat, msg.sender);
    if (userStats && userStats.stats && userStats.stats[today]) {
      userStats.stats[today].cmds++;
      await db.updateChatUser(msg.chat, msg.sender, 'stats', userStats.stats);
    }

    await cmdData.run({ msg, sock, args, command, usedPrefix, text, groupMetadata, participants, isAdmins, isBotAdmins, isOwner, __dirname: global.plugins[cmdData.pluginKey]?.dirname });
  } catch (error) {
    console.log(error);
    return msg.reply(`${error}`);
  }

};
  
